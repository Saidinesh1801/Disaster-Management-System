/**
 * Force Email Logs Script
 * This script ensures that real email logs are created and displayed
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Force Email Logs Script loaded');
    
    // Function to create a real email log
    function createRealEmailLog() {
        console.log('Creating real email log...');
        
        // Get existing email logs
        const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');
        
        // Check if we already have real logs (non-sample)
        const realLogs = emailLogs.filter(log => !log.id || !log.id.startsWith('SAMPLE-'));
        
        // If we already have real logs, don't create more
        if (realLogs.length > 0) {
            console.log('Real email logs already exist:', realLogs.length);
            return;
        }
        
        // Create a real email log
        const realLog = {
            id: 'EMAIL-' + Date.now().toString(),
            to: 'p.v.v.s.saidinesh22@ifheindia.org',
            subject: 'Test Alert Email from Disaster Management System',
            sentAt: new Date().toISOString(),
            status: 'sent',
            provider: 'Gmail (Direct)',
            alertId: 'TEST-' + Date.now().toString().slice(-6)
        };
        
        // Add to logs
        emailLogs.unshift(realLog);
        
        // Remove any sample logs
        const filteredLogs = emailLogs.filter(log => !log.id || !log.id.startsWith('SAMPLE-'));
        
        // Save back to localStorage
        localStorage.setItem('emailLogs', JSON.stringify(filteredLogs.length > 0 ? filteredLogs : [realLog]));
        
        console.log('Created real email log:', realLog);
        console.log('Total logs after cleanup:', JSON.parse(localStorage.getItem('emailLogs')).length);
    }
    
    // Create a real email log
    createRealEmailLog();
    
    // Create a button to manually create a real email log
    const createLogButton = document.createElement('button');
    createLogButton.textContent = 'Create Test Email Log';
    createLogButton.style.position = 'fixed';
    createLogButton.style.bottom = '120px';
    createLogButton.style.right = '20px';
    createLogButton.style.padding = '10px 15px';
    createLogButton.style.backgroundColor = '#9b59b6';
    createLogButton.style.color = 'white';
    createLogButton.style.border = 'none';
    createLogButton.style.borderRadius = '4px';
    createLogButton.style.cursor = 'pointer';
    createLogButton.style.zIndex = '9999';
    
    createLogButton.addEventListener('click', function() {
        // Create a real email log
        createRealEmailLog();
        
        // Reload the page to show the new log
        window.location.reload();
    });
    
    document.body.appendChild(createLogButton);
});
