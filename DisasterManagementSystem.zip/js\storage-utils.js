/**
 * Utility functions for handling localStorage operations
 * This ensures consistent access to stored data across all pages
 */

const StorageUtils = {
    /**
     * Save data to localStorage with error handling
     * @param {string} key - The localStorage key
     * @param {any} data - The data to save (will be JSON stringified)
     * @returns {boolean} - Success status
     */
    saveData: function(key, data) {
        try {
            const jsonData = JSON.stringify(data);
            localStorage.setItem(key, jsonData);
            console.log(`Data saved to ${key}:`, data);
            return true;
        } catch (error) {
            console.error(`Error saving data to ${key}:`, error);
            return false;
        }
    },
    
    /**
     * Load data from localStorage with error handling
     * @param {string} key - The localStorage key
     * @param {any} defaultValue - Default value if key doesn't exist or error occurs
     * @returns {any} - The parsed data or defaultValue
     */
    loadData: function(key, defaultValue = null) {
        try {
            const data = localStorage.getItem(key);
            if (data === null) {
                console.log(`No data found for ${key}, using default`);
                return defaultValue;
            }
            
            const parsedData = JSON.parse(data);
            console.log(`Data loaded from ${key}:`, parsedData);
            return parsedData;
        } catch (error) {
            console.error(`Error loading data from ${key}:`, error);
            return defaultValue;
        }
    },
    
    /**
     * Add an item to an array in localStorage
     * @param {string} key - The localStorage key for the array
     * @param {any} item - The item to add to the array
     * @returns {boolean} - Success status
     */
    addToArray: function(key, item) {
        try {
            // Get existing array or create new one
            let array = this.loadData(key, []);
            
            // Ensure we have an array
            if (!Array.isArray(array)) {
                console.warn(`Data in ${key} is not an array, creating new array`);
                array = [];
            }
            
            // Add item and save
            array.push(item);
            return this.saveData(key, array);
        } catch (error) {
            console.error(`Error adding item to ${key}:`, error);
            return false;
        }
    },
    
    /**
     * Clear all data for a specific key
     * @param {string} key - The localStorage key to clear
     */
    clearData: function(key) {
        localStorage.removeItem(key);
        console.log(`Cleared data for ${key}`);
    },
    
    /**
     * Initialize the storage with sample data if empty
     * @param {string} key - The localStorage key
     * @param {any} sampleData - Sample data to use if storage is empty
     */
    initializeWithSampleData: function(key, sampleData) {
        const existingData = this.loadData(key, null);
        
        if (existingData === null || (Array.isArray(existingData) && existingData.length === 0)) {
            console.log(`Initializing ${key} with sample data`);
            this.saveData(key, sampleData);
            return true;
        }
        
        return false;
    }
};
