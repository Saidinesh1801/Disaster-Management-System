/**
 * Navigation Menu Enhancement for Disaster Management System
 * This script adds interactive features to the navigation menu
 */

document.addEventListener('DOMContentLoaded', function() {
    // Menu structure with categories and items
    const menuStructure = [
        {
            category: 'Main',
            icon: '<i class="fas fa-home"></i>',
            items: [
                { url: 'home.html', label: 'Home', icon: '<i class="fas fa-home"></i>' },
                { url: 'about.html', label: 'About', icon: '<i class="fas fa-info-circle"></i>' }
            ]
        },
        {
            category: 'Alerts & Disasters',
            icon: '<i class="fas fa-exclamation-triangle"></i>',
            items: [
                { url: 'alert.html', label: 'Alerts', icon: '<i class="fas fa-bell"></i>' },
                { url: 'registered-alerts.html', label: 'Registered Alerts', icon: '<i class="fas fa-list-alt"></i>' },
                { url: 'occurred-disasters.html', label: 'Occurred Disasters', icon: '<i class="fas fa-exclamation-triangle"></i>' }
            ]
        },
        {
            category: 'Information',
            icon: '<i class="fas fa-info-circle"></i>',
            items: [
                { url: 'insight.html', label: 'Insights', icon: '<i class="fas fa-chart-line"></i>' },
                { url: 'precaution.html', label: 'Precautions', icon: '<i class="fas fa-shield-alt"></i>' }
            ]
        },
        {
            category: 'User Settings',
            icon: '<i class="fas fa-user-cog"></i>',
            items: [
                { url: 'email-logs.html', label: 'Email Logs', icon: '<i class="fas fa-envelope"></i>' },
                { url: 'user-preferences.html', label: 'Preferences', icon: '<i class="fas fa-cog"></i>' }
            ]
        }
    ];

    // Get the navigation menu
    const navLinks = document.querySelector('.nav-links');
    const navContainer = document.querySelector('.nav-container');

    // If navigation menu exists
    if (navLinks) {
        // Clear existing menu items except logout and welcome
        const logoutBtn = document.getElementById('logoutBtn');
        const userWelcome = document.getElementById('userWelcome');

        // Store logout and welcome elements if they exist
        const logoutElement = logoutBtn ? logoutBtn.parentElement : null;
        const welcomeElement = userWelcome ? userWelcome.parentElement : null;

        // Clear the navigation menu
        navLinks.innerHTML = '';

        // Add menu categories and items
        menuStructure.forEach((category, index) => {
            // Create category container
            const categoryItem = document.createElement('li');
            categoryItem.className = 'nav-category';

            // Create category header
            const categoryHeader = document.createElement('div');
            categoryHeader.className = 'category-header';
            categoryHeader.innerHTML = `${category.icon} ${category.category} <i class="fas fa-chevron-down"></i>`;
            categoryItem.appendChild(categoryHeader);

            // Create submenu container
            const submenu = document.createElement('ul');
            submenu.className = 'submenu';

            // Add submenu items
            category.items.forEach(item => {
                const submenuItem = document.createElement('li');
                submenuItem.innerHTML = `<a href="${item.url}">${item.icon} ${item.label}</a>`;
                submenu.appendChild(submenuItem);
            });

            // Add submenu to category
            categoryItem.appendChild(submenu);

            // Add category to menu
            navLinks.appendChild(categoryItem);

            // Direct click handler for category headers
            categoryHeader.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent event bubbling

                const isActive = this.parentElement.classList.contains('active');

                // Close all categories first
                document.querySelectorAll('.nav-category').forEach(cat => {
                    cat.classList.remove('active');
                    const chevron = cat.querySelector('.fa-chevron-up');
                    if (chevron) {
                        chevron.classList.remove('fa-chevron-up');
                        chevron.classList.add('fa-chevron-down');
                    }
                });

                // If it wasn't active before, make it active now
                if (!isActive) {
                    this.parentElement.classList.add('active');
                    const chevron = this.querySelector('.fa-chevron-down');
                    if (chevron) {
                        chevron.classList.remove('fa-chevron-down');
                        chevron.classList.add('fa-chevron-up');
                    }
                }
            };

            // Prevent clicks on submenu from closing the dropdown
            const submenu = categoryItem.querySelector('.submenu');
            if (submenu) {
                submenu.addEventListener('click', function(e) {
                    e.stopPropagation(); // Prevent event bubbling
                });
            }
        });

        // Add logout button
        if (logoutElement) {
            navLinks.appendChild(logoutElement);
        } else {
            // Create logout button if it didn't exist
            const logoutItem = document.createElement('li');
            logoutItem.innerHTML = '<a href="#" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>';
            navLinks.appendChild(logoutItem);

            // Add event listener to new logout button
            document.getElementById('logoutBtn').addEventListener('click', function(e) {
                e.preventDefault();

                // Get user session
                const userSession = JSON.parse(localStorage.getItem('currentUserSession'));

                // Update session status
                if (userSession) {
                    // Mark session as inactive
                    userSession.active = false;
                    localStorage.setItem('currentUserSession', JSON.stringify(userSession));

                    // Update active users list
                    let activeUsers = JSON.parse(localStorage.getItem('activeUsers') || '[]');
                    activeUsers = activeUsers.filter(user => user.userId !== userSession.userId);
                    localStorage.setItem('activeUsers', JSON.stringify(activeUsers));
                }

                // Redirect to login page
                window.location.href = 'index.html';
            });
        }

        // Add welcome message if it existed
        if (welcomeElement) {
            navLinks.appendChild(welcomeElement);
        }

        // Add mobile navigation toggle button
        const navbar = document.querySelector('.navbar');
        const navContainer = document.querySelector('.nav-container');

        // Create toggle button
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'nav-toggle-btn';
        toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
        navContainer.prepend(toggleBtn);

        // Toggle mobile menu
        toggleBtn.addEventListener('click', function() {
            navbar.classList.toggle('mobile-open');

            // Change icon based on state
            if (navbar.classList.contains('mobile-open')) {
                toggleBtn.innerHTML = '<i class="fas fa-times"></i>';
            } else {
                toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });

        // Close dropdown menus when clicking outside
        document.addEventListener('click', function(e) {
            // Only close if click is outside any nav-category
            if (!e.target.closest('.nav-category') && !e.target.closest('.nav-toggle-btn')) {
                document.querySelectorAll('.nav-category').forEach(cat => {
                    cat.classList.remove('active');
                    const chevron = cat.querySelector('.fa-chevron-up');
                    if (chevron) {
                        chevron.classList.remove('fa-chevron-up');
                        chevron.classList.add('fa-chevron-down');
                    }
                });
            }
        });

        // Make group labels clickable on mobile
        const groupLabels = document.querySelectorAll('.nav-group-label');
        groupLabels.forEach(label => {
            label.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    const group = this.closest('.nav-group');
                    group.classList.toggle('expanded');
                }
            });
        });

        // Highlight current page in the menu
        // Get current page filename
        const currentPage = window.location.pathname.split('/').pop() || 'home.html';

        // Make sure all categories are initially collapsed
        document.querySelectorAll('.nav-category').forEach(cat => {
            cat.classList.remove('active');
        });

        // Find and highlight the current page link
        const links = document.querySelectorAll('.submenu a');
        let activeFound = false;

        links.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPage) {
                link.classList.add('active');
                activeFound = true;

                // Expand only the parent category of the active link
                const category = link.closest('.nav-category');
                if (category) {
                    category.classList.add('active');

                    // Update the chevron icon
                    const chevron = category.querySelector('.fa-chevron-down');
                    if (chevron) {
                        chevron.classList.remove('fa-chevron-down');
                        chevron.classList.add('fa-chevron-up');
                    }
                }
            }
        });

        // If no active page found (e.g., on index.html), default to expanding Main category
        if (!activeFound && currentPage === 'index.html') {
            const mainCategory = document.querySelector('.nav-category');
            if (mainCategory) {
                mainCategory.classList.add('active');
                const chevron = mainCategory.querySelector('.fa-chevron-down');
                if (chevron) {
                    chevron.classList.remove('fa-chevron-down');
                    chevron.classList.add('fa-chevron-up');
                }
            }
        }
    }
});
