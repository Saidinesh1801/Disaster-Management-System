/**
 * Direct Email Service
 * This is a completely new implementation that bypasses the existing email service
 */

const DirectEmailService = {
    // API configuration
    apiUrl: 'http://localhost:3000/api',

    /**
     * Send an alert email directly to the server
     * @param {Object} alert - The alert object
     * @param {Array} recipients - Array of recipient objects with email and name
     * @returns {Promise} - Promise that resolves when the email is sent
     */
    sendAlertEmail: function(alert, recipients) {
        console.log('DIRECT EMAIL: Sending alert email directly to server');
        console.log('- Alert:', alert);
        console.log('- Recipients:', recipients);

        // Validate recipients
        if (!recipients || recipients.length === 0) {
            console.error('DIRECT EMAIL: No recipients provided');
            this.showNotification('Error: No email recipients provided', 'error');
            return Promise.reject(new Error('No recipients provided'));
        }

        // Validate recipient emails
        const validRecipients = recipients.filter(r => r && r.email && r.email.includes('@'));
        if (validRecipients.length === 0) {
            console.error('DIRECT EMAIL: No valid email addresses found in recipients');
            this.showNotification('Error: No valid email addresses found', 'error');
            return Promise.reject(new Error('No valid email addresses found'));
        }

        // Add test recipient to ensure at least one email is sent
        const testEmail = 'p.v.v.s.saidinesh22@ifheindia.org';
        if (!validRecipients.some(r => r.email === testEmail)) {
            validRecipients.push({
                email: testEmail,
                name: 'Test Recipient'
            });
            console.log('DIRECT EMAIL: Added test recipient to ensure delivery');
        }

        // Create request data with enhanced properties
        const requestData = {
            recipients: validRecipients.map(recipient => ({
                email: recipient.email,
                fullname: recipient.name || ''
            })),
            alert: {
                id: alert.id || 'ALT-' + Date.now(),
                disasterType: alert.disasterType || 'Emergency Alert',
                regions: alert.location || alert.regions || alert.affectedAreas || 'All Regions',
                severity: alert.severity || 'High',
                datetime: alert.timestamp || new Date().toISOString(),
                message: alert.description || alert.message || 'Emergency alert notification',
                issuedBy: alert.reportedBy || alert.issuedBy || 'Disaster Management System',
                evacuationOrders: alert.evacuationOrders || 'Follow local authority instructions',
                emergencyContacts: alert.emergencyContacts || 'Emergency Services: 911'
            }
        };

        console.log('DIRECT EMAIL: Enhanced request data:', requestData);

        // Show sending notification with count
        this.showNotification(`Sending email alert to ${validRecipients.length} recipients...`, 'info');

        // Send the request with timeout and retry logic
        return this._fetchWithRetry(`${this.apiUrl}/send-alert`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        }, 3) // 3 retries
        .then(response => {
            console.log('DIRECT EMAIL: Response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('DIRECT EMAIL: Response data:', data);

            if (data.success) {
                // Show success notification
                this.showNotification(`Email alert sent successfully to ${validRecipients.length} recipients!`, 'success');

                // Log emails to localStorage
                validRecipients.forEach(recipient => {
                    this.logEmailSent({
                        to: recipient.email,
                        subject: `${alert.disasterType} Alert for ${alert.regions}`,
                        sentAt: new Date().toISOString(),
                        status: 'sent',
                        provider: 'Gmail (Direct)',
                        alertId: alert.id
                    });
                });

                // Also send a test email to verify
                return this.sendTestEmail();
            } else {
                throw new Error(data.message || 'Failed to send email alert');
            }
        })
        .catch(error => {
            console.error('DIRECT EMAIL: Error sending alert:', error);

            // Show error notification
            this.showNotification(`Error sending email alert: ${error.message}. Trying alternative method...`, 'error');

            // Try sending a test email anyway
            this.sendTestEmail();

            // Try alternative method - direct test email
            setTimeout(() => {
                window.open(`${this.apiUrl}/test-email?email=${encodeURIComponent(validRecipients[0].email)}`, '_blank');
            }, 1000);

            throw error;
        });
    },

    /**
     * Fetch with retry logic
     * @param {string} url - The URL to fetch
     * @param {Object} options - Fetch options
     * @param {number} retries - Number of retries
     * @returns {Promise} - Promise that resolves with the fetch response
     */
    _fetchWithRetry: function(url, options, retries) {
        return fetch(url, options)
            .catch(error => {
                if (retries <= 0) {
                    throw error;
                }

                console.log(`DIRECT EMAIL: Retrying fetch (${retries} retries left)...`);
                return new Promise(resolve => setTimeout(resolve, 1000))
                    .then(() => this._fetchWithRetry(url, options, retries - 1));
            });
    },

    /**
     * Send a test email
     * @returns {Promise} - Promise that resolves when the test email is sent
     */
    sendTestEmail: function() {
        console.log('DIRECT EMAIL: Sending test email');

        return fetch(`${this.apiUrl}/test-email`)
            .then(response => {
                console.log('DIRECT EMAIL: Test email response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('DIRECT EMAIL: Test email response data:', data);

                if (data.success) {
                    // Show success notification
                    this.showNotification(`Test email sent to ${data.details.recipient}`, 'success');

                    // Log test email in localStorage
                    this.logEmailSent({
                        to: data.details.recipient,
                        subject: 'Test Email from Disaster Management System',
                        sentAt: new Date().toISOString(),
                        status: 'sent',
                        provider: 'Gmail (Direct)',
                        alertId: 'TEST-' + Date.now().toString().slice(-6)
                    });

                    return data;
                } else {
                    throw new Error(data.message || 'Failed to send test email');
                }
            })
            .catch(error => {
                console.error('DIRECT EMAIL: Error sending test email:', error);

                // Show error notification
                this.showNotification(`Error sending test email: ${error.message}`, 'error');

                throw error;
            });
    },

    /**
     * Log sent email in localStorage
     * @param {Object} emailData - Email data to log
     */
    logEmailSent: function(emailData) {
        console.log('DIRECT EMAIL: Logging email to localStorage:', emailData);

        // Get existing email logs
        const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');

        // Add new log entry with unique ID
        emailLogs.unshift({
            ...emailData,
            id: 'EMAIL-' + Date.now().toString()
        });

        // Save back to localStorage
        localStorage.setItem('emailLogs', JSON.stringify(emailLogs));

        console.log('DIRECT EMAIL: Email logged successfully. Total logs:', emailLogs.length);
    },

    /**
     * Show a notification message
     * @param {string} message - The message to display
     * @param {string} type - The type of notification (success, error, info)
     * @param {number} duration - How long to show the notification in ms
     */
    showNotification: function(message, type = 'info', duration = 5000) {
        // Create notification element
        const notification = document.createElement('div');
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.padding = '15px 20px';
        notification.style.borderRadius = '4px';
        notification.style.color = 'white';
        notification.style.fontWeight = 'bold';
        notification.style.zIndex = '9999';
        notification.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';

        // Set background color based on type
        if (type === 'success') {
            notification.style.backgroundColor = '#28a745';
        } else if (type === 'error') {
            notification.style.backgroundColor = '#dc3545';
        } else {
            notification.style.backgroundColor = '#17a2b8';
        }

        // Set message
        notification.textContent = message;

        // Add to body
        document.body.appendChild(notification);

        // Remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);

        return notification;
    }
};

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('DIRECT EMAIL: Service initialized');
    // Test button removed as requested
});
