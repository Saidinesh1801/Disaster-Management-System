/**
 * Direct Alert Handler
 * This script overrides the alert form submission to use the direct email service
 *
 * IMPORTANT: This handler is now DISABLED to prevent duplicate emails
 * The original form submission in alert.html will handle email sending
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('DIRECT ALERT HANDLER: Initializing - DISABLED to prevent duplicate emails');

    // This handler is now disabled to prevent duplicate emails
    // The original form submission in alert.html will handle email sending

    /*
    // Wait for the alert form to be available
    const checkForm = setInterval(() => {
        const alertForm = document.getElementById('alertForm');

        if (alertForm) {
            clearInterval(checkForm);
            console.log('DIRECT ALERT HANDLER: Alert form found, overriding submission');

            // Override the form submission
            alertForm.addEventListener('submit', function(e) {
                // Prevent the default form submission
                e.preventDefault();
                e.stopPropagation();
    */

                /*
                console.log('DIRECT ALERT HANDLER: Form submitted');

                // Get form values
                const disasterType = document.getElementById('disasterType').value;
                const location = document.getElementById('location').value;
                const affectedAreas = Array.from(document.getElementById('affectedAreas').options)
                    .filter(option => option.selected)
                    .map(option => option.value)
                    .join(', ') || location;
                const severity = document.getElementById('severity').value;
                const status = document.getElementById('status').value;
                const description = document.getElementById('description').value;
                const evacuationOrders = document.getElementById('evacuationOrders').value || 'No evacuation orders at this time';
                const emergencyContacts = document.getElementById('emergencyContacts').value || 'Local emergency services';
                const sendEmails = document.getElementById('sendEmails').checked;

                // Generate a unique ID for the alert
                const alertId = 'ALT' + Date.now().toString().slice(-6);
                const currentDate = new Date().toISOString().split('T')[0];
                const timestamp = new Date().toISOString();

                // Get current user info
                const session = JSON.parse(localStorage.getItem('currentUserSession'));
                const reportedBy = session && session.user ? (session.user.fullname || session.user.username) : 'System Admin';

                // Create alert object
                const newAlert = {
                    id: alertId,
                    disasterType: disasterType,
                    date: currentDate,
                    location: location,
                    severity: severity,
                    affectedAreas: affectedAreas,
                    status: status,
                    description: description,
                    reportedBy: reportedBy,
                    timestamp: timestamp,
                    evacuationOrders: evacuationOrders,
                    emergencyContacts: emergencyContacts
                };

                console.log('DIRECT ALERT HANDLER: New alert created:', newAlert);

                // Save to localStorage - using both methods to ensure compatibility
                // Method 1: Using addToArray (our new method)
                const success1 = StorageUtils.addToArray('registeredAlerts', newAlert);

                // Method 2: Direct localStorage update (for compatibility with registered-alerts.html)
                // Get existing alerts
                let existingAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');
                // Add new alert
                existingAlerts.push(newAlert);
                // Save back to localStorage
                localStorage.setItem('registeredAlerts', JSON.stringify(existingAlerts));

                // Log the alert data to console for debugging
                console.log('DIRECT ALERT HANDLER: New alert data:', newAlert);
                console.log('DIRECT ALERT HANDLER: All alerts in localStorage:', existingAlerts);

                if (!success1) {
                    alert('There was an error saving the alert. Please try again.');
                    return;
                }

                // Verify the alert was saved
                const savedAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');
                console.log('DIRECT ALERT HANDLER: Alert successfully added. Total alerts:', savedAlerts.length);

                // Show a loading message
                const loadingMessage = document.createElement('div');
                loadingMessage.className = 'loading-message';
                loadingMessage.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing alert...';
                document.body.appendChild(loadingMessage);

                // Send email notifications if checked
                if (sendEmails) {
                    console.log('DIRECT ALERT HANDLER: Sending email notifications');

                    // Get current user email
                    const currentUserEmail = session && session.user ? session.user.email : '';
                    const currentUserName = session && session.user ? (session.user.fullname || session.user.username) : 'User';

                    // Create recipients list
                    const recipients = [{
                        email: currentUserEmail,
                        name: currentUserName
                    }];

                    // Send email using direct email service
                    DirectEmailService.sendAlertEmail(newAlert, recipients)
                        .then(function() {
                            console.log('DIRECT ALERT HANDLER: Email sent successfully');

                            // Remove loading message
                            if (loadingMessage.parentNode) {
                                loadingMessage.parentNode.removeChild(loadingMessage);
                            }

                            // Reset form and redirect
                            resetFormAndRedirect();
                        })
                        .catch(function(error) {
                            console.error('DIRECT ALERT HANDLER: Error sending email:', error);

                            // Remove loading message
                            if (loadingMessage.parentNode) {
                                loadingMessage.parentNode.removeChild(loadingMessage);
                            }

                            // Reset form and redirect
                            resetFormAndRedirect();
                        });
                } else {
                    console.log('DIRECT ALERT HANDLER: Email notifications not requested');

                    // Remove loading message
                    setTimeout(() => {
                        if (loadingMessage.parentNode) {
                            loadingMessage.parentNode.removeChild(loadingMessage);
                        }

                        // Reset form and redirect
                        resetFormAndRedirect();
                    }, 1000);
                }

                // Function to reset form and redirect
                function resetFormAndRedirect() {
                    // Show success message
                    alert(`Alert ${alertId} has been created successfully!`);

                    // Reset the form
                    alertForm.reset();

                    // Reset Select2 if it's being used
                    if ($.fn.select2) {
                        $('#affectedAreas').val(null).trigger('change');
                    }

                    // Redirect to registered alerts page
                    window.location.href = 'registered-alerts.html';
                }

                // Return false to prevent the default form submission
                return false;
            }, true);

            console.log('DIRECT ALERT HANDLER: Form submission override complete');
        }
    }, 100);
    */

    // Just log that this handler is disabled
    console.log('DIRECT ALERT HANDLER: Handler is disabled to prevent duplicate emails');
});
