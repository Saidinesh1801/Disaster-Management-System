// Sample data for the Disaster Management System

// Create a sample user if none exist
function createSampleUser() {
    // Check if users already exist
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');

    if (users.length === 0) {
        // Create a sample user
        const sampleUser = {
            id: "user-" + Date.now(),
            fullname: "Demo User",
            username: "demo",
            email: "demo@example.com",
            password: "password", // In a real app, this would be hashed
            dateRegistered: new Date().toISOString(),
            preferences: {
                receiveAlerts: true,
                alertTypes: ["All"]
            }
        };

        // Add to users array
        users.push(sampleUser);

        // Save to localStorage
        localStorage.setItem('registeredUsers', JSON.stringify(users));
        console.log("Sample user created: username=demo, email=demo@example.com, password=password");
    }
}

// Create sample alerts if none exist
function createSampleAlerts() {
    // Check if alerts already exist
    const alerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');

    if (alerts.length === 0) {
        // Create sample alerts with the structure matching alert.html
        const sampleAlerts = [
            {
                id: "ALT-2023-001",
                disasterType: "Earthquake",
                date: "2023-04-15",
                location: "Japan, Philippines",
                severity: "High",
                affectedAreas: "Tokyo, Manila, Coastal Regions",
                status: "Active",
                description: "A strong earthquake has been detected off the coast of Japan. Tsunami warnings have been issued for coastal areas. Please evacuate to higher ground immediately.",
                reportedBy: "Japan Meteorological Agency",
                timestamp: "2023-04-15T08:30:22",
                evacuationOrders: "Mandatory evacuation for coastal areas",
                emergencyContacts: "Emergency Services: 119 (Japan) / 911 (Philippines)"
            },
            {
                id: "ALT-2023-002",
                disasterType: "Flood",
                date: "2023-05-22",
                location: "India, Bangladesh",
                severity: "Critical",
                affectedAreas: "Ganges Delta, Kolkata, Dhaka",
                status: "Active",
                description: "Severe flooding is occurring in the Ganges Delta region. Multiple rivers have breached their banks. Evacuate low-lying areas immediately and move to designated shelters.",
                reportedBy: "Indian Meteorological Department",
                timestamp: "2023-05-22T14:45:10",
                evacuationOrders: "Evacuate low-lying areas immediately",
                emergencyContacts: "Emergency Services: 112 (India) / 999 (Bangladesh)"
            },
            {
                id: "ALT-2023-003",
                disasterType: "Hurricane",
                date: "2023-06-10",
                location: "United States (Florida, Georgia)",
                severity: "High",
                affectedAreas: "Miami, Jacksonville, Savannah",
                status: "Active",
                description: "Hurricane Maria is approaching the Florida coast. Mandatory evacuation orders are in effect for coastal counties. Seek shelter inland immediately.",
                reportedBy: "National Hurricane Center",
                timestamp: "2023-06-10T17:20:05",
                evacuationOrders: "Mandatory evacuation for coastal counties",
                emergencyContacts: "Emergency Services: 911, FEMA: 1-800-621-3362"
            }
        ];

        // Add to alerts array
        alerts.push(...sampleAlerts);

        // Save to localStorage
        localStorage.setItem('registeredAlerts', JSON.stringify(alerts));
        console.log("Sample alerts created");
    }
}

// Create sample email logs if none exist
function createSampleEmailLogs() {
    // Check if email logs already exist
    const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');

    if (emailLogs.length === 0) {
        // Create sample email logs that match the structure in alert.html
        const sampleLogs = [
            {
                id: 'EMAIL' + Math.floor(Math.random() * 10000) + '1',
                alertId: 'ALT-2023-001',
                disasterType: 'Earthquake',
                location: 'Japan, Philippines',
                severity: 'High',
                sentDate: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
                recipients: 'user1@example.com',
                status: 'Sent'
            },
            {
                id: 'EMAIL' + Math.floor(Math.random() * 10000) + '2',
                alertId: 'ALT-2023-002',
                disasterType: 'Flood',
                location: 'India, Bangladesh',
                severity: 'Critical',
                sentDate: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), // 5 hours ago
                recipients: 'user2@example.com',
                status: 'Sent'
            },
            {
                id: 'EMAIL' + Math.floor(Math.random() * 10000) + '3',
                alertId: 'ALT-2023-003',
                disasterType: 'Hurricane',
                location: 'United States (Florida, Georgia)',
                severity: 'High',
                sentDate: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
                recipients: 'user3@example.com',
                status: 'Failed',
                error: 'Connection timeout'
            }
        ];

        // Save to localStorage
        localStorage.setItem('emailLogs', JSON.stringify(sampleLogs));
        console.log("Sample email logs created");
    }
}

// Initialize all sample data
function initializeSampleData() {
    createSampleUser();
    createSampleAlerts();
    createSampleEmailLogs();
    console.log("Sample data initialization complete");
}

// Run initialization when the script loads
initializeSampleData();
