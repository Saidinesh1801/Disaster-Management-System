/**
 * Create Test User Script
 * This script creates a test user with a valid email address
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('CREATE TEST USER: Script loaded');
    // Test button removed as requested

    // Function to create a test user
    function createTestUser() {
        console.log('CREATE TEST USER: Creating test user');

        // Prompt for email address
        const email = prompt('Enter a valid email address for the test user:');

        if (!email || !isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }

        // Create a test user
        const testUser = {
            id: 'TEST' + Date.now().toString(),
            fullname: 'Test User',
            username: 'testuser',
            email: email,
            password: 'password123', // In a real app, this would be hashed
            dateRegistered: new Date().toISOString(),
            preferences: {
                receiveAlerts: true,
                alertTypes: ['All']
            }
        };

        console.log('CREATE TEST USER: User data:', testUser);

        // Get existing users or initialize empty array
        let users = [];
        try {
            users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
            console.log('CREATE TEST USER: Existing users:', users);
        } catch (e) {
            console.error('CREATE TEST USER: Error parsing existing users:', e);
            users = [];
        }

        // Check if user with same email already exists
        const existingUserIndex = users.findIndex(user => user.email.toLowerCase() === email.toLowerCase());

        if (existingUserIndex >= 0) {
            // Update existing user
            users[existingUserIndex] = testUser;
            console.log('CREATE TEST USER: Updated existing user');
        } else {
            // Add new user
            users.push(testUser);
            console.log('CREATE TEST USER: Added new user');
        }

        // Save back to localStorage
        localStorage.setItem('registeredUsers', JSON.stringify(users));

        // Create a session for the test user
        const session = {
            userId: testUser.id,
            username: testUser.username,
            email: testUser.email,
            fullname: testUser.fullname,
            loginTime: new Date().toISOString(),
            active: true,
            user: testUser // Include the full user object
        };

        // Save session to localStorage
        localStorage.setItem('currentUserSession', JSON.stringify(session));

        // Add to active users list
        let activeUsers = [];
        try {
            activeUsers = JSON.parse(localStorage.getItem('activeUsers') || '[]');
        } catch (e) {
            console.error('CREATE TEST USER: Error parsing active users:', e);
            activeUsers = [];
        }

        // Remove any existing session for this user
        activeUsers = activeUsers.filter(activeUser => activeUser.userId !== testUser.id);

        // Add new session
        activeUsers.push(session);

        // Save back to localStorage
        localStorage.setItem('activeUsers', JSON.stringify(activeUsers));

        console.log('CREATE TEST USER: User created and logged in successfully');
        alert('Test user created and logged in successfully with email: ' + email);

        // Reload the page to update the UI
        window.location.reload();
    }

    // Function to validate email format
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});
