/**
 * Test Alert Script
 * This script directly adds a test alert to localStorage
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('TEST ALERT: Script loaded');
    // Test button removed as requested

    // Function to add a test alert
    function addTestAlert() {
        console.log('TEST ALERT: Adding test alert');

        // Create a test alert
        const testAlert = {
            id: 'TEST' + Date.now(),
            disasterType: 'Test Disaster',
            date: new Date().toISOString().split('T')[0],
            location: 'Test Location',
            severity: 'High',
            affectedAreas: 'Test Area 1, Test Area 2',
            status: 'Active',
            description: 'This is a test alert created at ' + new Date().toLocaleTimeString(),
            reportedBy: 'Test Script',
            timestamp: new Date().toISOString(),
            evacuationOrders: 'Test evacuation orders',
            emergencyContacts: 'Test emergency contacts'
        };

        console.log('TEST ALERT: Alert data:', testAlert);

        // Method 1: Direct localStorage update
        try {
            // Get existing alerts
            let existingAlerts = [];
            try {
                existingAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');
                console.log('TEST ALERT: Existing alerts:', existingAlerts);
            } catch (e) {
                console.error('TEST ALERT: Error parsing existing alerts:', e);
                existingAlerts = [];
            }

            // Add new alert
            existingAlerts.push(testAlert);

            // Save back to localStorage
            localStorage.setItem('registeredAlerts', JSON.stringify(existingAlerts));

            console.log('TEST ALERT: Alert added successfully. Total alerts:', existingAlerts.length);
            alert('Test alert added successfully! Please check the registered alerts page.');
        } catch (e) {
            console.error('TEST ALERT: Error adding alert:', e);
            alert('Error adding test alert: ' + e.message);
        }
    }
});
