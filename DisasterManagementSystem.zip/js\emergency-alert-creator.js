/**
 * Emergency Alert Creator
 * This script adds a very visible button to create alerts
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Emergency Alert Creator loaded');
    // Emergency button removed as requested

    // Function to create an emergency alert
    function createEmergencyAlert() {
        console.log('Creating emergency alert...');

        // Get values from the form if they exist, otherwise use defaults
        const disasterTypeElement = document.getElementById('disasterType');
        const locationElement = document.getElementById('location');
        const severityElement = document.getElementById('severity');
        const statusElement = document.getElementById('status');
        const descriptionElement = document.getElementById('description');

        const disasterType = disasterTypeElement && disasterTypeElement.value ?
            disasterTypeElement.value : 'Earthquake';

        const location = locationElement && locationElement.value ?
            locationElement.value : 'California, USA';

        const severity = severityElement && severityElement.value ?
            severityElement.value : 'High';

        const status = statusElement && statusElement.value ?
            statusElement.value : 'Active';

        const description = descriptionElement && descriptionElement.value ?
            descriptionElement.value : 'Emergency alert created for immediate action.';

        // Generate a unique ID for the alert
        const alertId = 'EMERG-' + Date.now().toString().slice(-6);
        const currentDate = new Date().toISOString().split('T')[0];
        const timestamp = new Date().toISOString();

        // Create alert object
        const newAlert = {
            id: alertId,
            disasterType: disasterType,
            date: currentDate,
            location: location,
            severity: severity,
            affectedAreas: location,
            status: status,
            description: description,
            reportedBy: 'Emergency System',
            timestamp: timestamp,
            evacuationOrders: 'Evacuate immediately',
            emergencyContacts: 'Emergency Services: 911'
        };

        console.log('Emergency alert object:', newAlert);

        // Save directly to localStorage
        try {
            // Get existing alerts
            let existingAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');

            // Add new alert
            existingAlerts.push(newAlert);

            // Save back to localStorage
            localStorage.setItem('registeredAlerts', JSON.stringify(existingAlerts));

            console.log('Emergency alert saved directly to localStorage');
            console.log('Total alerts:', existingAlerts.length);

            // Show success message
            alert(`Emergency alert ${alertId} has been created successfully!`);

            // Redirect to registered alerts page
            window.location.href = 'registered-alerts.html';
        } catch (error) {
            console.error('Error saving emergency alert:', error);
            alert('Error creating emergency alert: ' + error.message);
        }
    }
});
