/**
 * Direct Alert Creator
 * This script creates alerts directly without using the form submission
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Direct Alert Creator loaded');
    // Test button removed as requested
});
