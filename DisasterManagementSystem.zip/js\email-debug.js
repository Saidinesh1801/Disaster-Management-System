/**
 * Email Debug Script
 * This script adds detailed logging to help diagnose email sending issues
 */

// Execute immediately when loaded
(function() {
    console.log('EMAIL DEBUG: Script loaded');
    
    // Add a global error handler
    window.addEventListener('error', function(event) {
        console.error('GLOBAL ERROR:', event.message, event.filename, event.lineno, event.colno, event.error);
    });
    
    // Override fetch to log all API calls
    const originalFetch = window.fetch;
    window.fetch = function(url, options) {
        console.log('FETCH REQUEST:', url, options);
        
        return originalFetch.apply(this, arguments)
            .then(response => {
                console.log('FETCH RESPONSE:', url, response.status);
                return response;
            })
            .catch(error => {
                console.error('FETCH ERROR:', url, error);
                throw error;
            });
    };
    
    // Wait for EmailService to be defined
    const checkEmailService = setInterval(() => {
        if (typeof EmailService !== 'undefined') {
            clearInterval(checkEmailService);
            
            console.log('EMAIL DEBUG: EmailService found, adding debug hooks');
            
            // Log the current configuration
            console.log('EMAIL CONFIG:', JSON.stringify(EmailService.config, null, 2));
            
            // Override sendAlertToAllUsers to add more logging
            const originalSendAlertToAllUsers = EmailService.sendAlertToAllUsers;
            EmailService.sendAlertToAllUsers = function(alert, additionalRecipients) {
                console.log('EMAIL DEBUG: sendAlertToAllUsers called');
                console.log('- Alert:', JSON.stringify(alert, null, 2));
                console.log('- Additional Recipients:', JSON.stringify(additionalRecipients, null, 2));
                
                // Check if real emails are enabled
                console.log('- Real Emails Enabled:', EmailService.config.useRealEmails);
                console.log('- Backend Server Enabled:', EmailService.config.useBackendServer);
                
                // Force real email mode
                EmailService.config.useRealEmails = true;
                EmailService.config.useBackendServer = true;
                
                console.log('- FORCED Real Emails Enabled:', EmailService.config.useRealEmails);
                console.log('- FORCED Backend Server Enabled:', EmailService.config.useBackendServer);
                
                return originalSendAlertToAllUsers.apply(this, arguments)
                    .then(result => {
                        console.log('EMAIL DEBUG: sendAlertToAllUsers succeeded:', result);
                        return result;
                    })
                    .catch(error => {
                        console.error('EMAIL DEBUG: sendAlertToAllUsers failed:', error);
                        throw error;
                    });
            };
            
            // Add a test function to directly call the API
            EmailService.testDirectApiCall = function() {
                console.log('EMAIL DEBUG: Testing direct API call');
                
                const apiUrl = `${EmailService.config.apiUrl}/test-email`;
                console.log('- API URL:', apiUrl);
                
                return fetch(apiUrl)
                    .then(response => {
                        console.log('- API Response Status:', response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log('- API Response Data:', data);
                        return data;
                    })
                    .catch(error => {
                        console.error('- API Error:', error);
                        throw error;
                    });
            };
            
            // Test the API connection immediately
            EmailService.testDirectApiCall()
                .then(() => {
                    console.log('EMAIL DEBUG: API test successful');
                })
                .catch(() => {
                    console.error('EMAIL DEBUG: API test failed');
                });
        }
    }, 100);
})();
