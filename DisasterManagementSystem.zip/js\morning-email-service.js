/**
 * Morning Email Service
 * This is an exact replica of the email service that was working this morning
 */

const MorningEmailService = {
    // API configuration
    apiUrl: 'http://localhost:3006',

    /**
     * Send an alert email
     * @param {Object} alert - The alert object
     * @param {Object} recipient - The recipient object with email and name
     * @returns {Promise} - Promise that resolves when the email is sent
     */
    sendAlertEmail: function(alert, recipient) {
        console.log('MORNING EMAIL: Sending alert email to', recipient.email);
        console.log('MORNING EMAIL: Alert data:', alert);

        // Create the loading overlay
        const overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        overlay.style.display = 'flex';
        overlay.style.justifyContent = 'center';
        overlay.style.alignItems = 'center';
        overlay.style.zIndex = '9999';

        const content = document.createElement('div');
        content.style.backgroundColor = '#fff';
        content.style.padding = '20px';
        content.style.borderRadius = '5px';
        content.style.display = 'flex';
        content.style.alignItems = 'center';
        content.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';

        const spinner = document.createElement('div');
        spinner.style.width = '24px';
        spinner.style.height = '24px';
        spinner.style.border = '3px solid #f3f3f3';
        spinner.style.borderTop = '3px solid #3498db';
        spinner.style.borderRadius = '50%';
        spinner.style.marginRight = '10px';
        spinner.style.animation = 'spin 1s linear infinite';

        // Add the spin animation if it doesn't exist
        if (!document.getElementById('spin-animation')) {
            const style = document.createElement('style');
            style.id = 'spin-animation';
            style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
            document.head.appendChild(style);
        }

        const message = document.createElement('span');
        message.textContent = 'Sending email alerts...';
        message.style.fontFamily = 'Arial, sans-serif';

        content.appendChild(spinner);
        content.appendChild(message);
        overlay.appendChild(content);
        document.body.appendChild(overlay);

        // Force recipient email if empty or invalid
        if (!recipient || !recipient.email || recipient.email.trim() === '' || !recipient.email.includes('@')) {
            console.warn('MORNING EMAIL: Invalid or empty recipient email. Using default email instead.');
            recipient = {
                email: 'p.v.v.s.saidinesh22@ifheindia.org',
                name: 'Test Recipient'
            };
        }

        // Create email log entry
        const emailLogEntry = {
            id: 'EMAIL-MORNING-' + Date.now().toString(),
            to: recipient.email,
            subject: `${alert.disasterType} Alert for ${alert.regions || alert.location || 'All Regions'}`,
            sentAt: new Date().toISOString(),
            status: 'sending',
            provider: 'Gmail (Morning)',
            alertId: alert.id || 'ALT-' + Date.now().toString().slice(-6)
        };

        // Log the email immediately to ensure it appears in logs
        console.log('MORNING EMAIL: Creating email log entry:', emailLogEntry);
        const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');
        emailLogs.unshift(emailLogEntry);
        localStorage.setItem('emailLogs', JSON.stringify(emailLogs));

        // Send the request
        return fetch(`${this.apiUrl}/send-alert`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                recipient: {
                    email: recipient.email,
                    fullname: recipient.name || recipient.fullname || 'Test Recipient'
                },
                alert: {
                    id: alert.id || 'ALT-' + Date.now(),
                    disasterType: alert.disasterType || 'Emergency Alert',
                    regions: alert.location || alert.regions || alert.affectedAreas || 'All Regions',
                    severity: alert.severity || 'High',
                    datetime: alert.timestamp || new Date().toISOString(),
                    message: alert.description || alert.message || 'Emergency alert notification',
                    issuedBy: alert.reportedBy || alert.issuedBy || 'Disaster Management System',
                    evacuationOrders: alert.evacuationOrders || 'Follow local authority instructions',
                    emergencyContacts: alert.emergencyContacts || 'Emergency Services: 911',
                    recipientName: recipient.name || recipient.fullname || 'Test Recipient'
                }
            })
        })
        .then(response => {
            console.log('MORNING EMAIL: Alert email response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('MORNING EMAIL: Alert email response data:', data);

            // Update the email log entry
            const updatedLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');
            const logIndex = updatedLogs.findIndex(log => log.id === emailLogEntry.id);
            if (logIndex !== -1) {
                updatedLogs[logIndex].status = 'sent';
                localStorage.setItem('emailLogs', JSON.stringify(updatedLogs));
            }

            // Remove the overlay after a delay to ensure it's visible
            setTimeout(() => {
                if (overlay && overlay.parentNode) {
                    overlay.parentNode.removeChild(overlay);
                }
            }, 2000);

            return data;
        })
        .catch(error => {
            console.error('MORNING EMAIL: Error sending alert email:', error);

            // Update the email log entry
            const updatedLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');
            const logIndex = updatedLogs.findIndex(log => log.id === emailLogEntry.id);
            if (logIndex !== -1) {
                updatedLogs[logIndex].status = 'failed';
                updatedLogs[logIndex].error = error.message;
                localStorage.setItem('emailLogs', JSON.stringify(updatedLogs));
            }

            // Remove the overlay
            if (overlay && overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }

            throw error;
        });
    },

    /**
     * Show a notification message
     * @param {string} message - The message to display
     * @param {string} type - The type of notification (success, error, info)
     * @param {number} duration - How long to show the notification in ms
     */
    showNotification: function(message, type = 'info', duration = 5000) {
        // Create notification element
        const notification = document.createElement('div');
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.padding = '15px 20px';
        notification.style.borderRadius = '4px';
        notification.style.color = 'white';
        notification.style.fontWeight = 'bold';
        notification.style.zIndex = '9999';
        notification.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';

        // Set background color based on type
        if (type === 'success') {
            notification.style.backgroundColor = '#28a745';
        } else if (type === 'error') {
            notification.style.backgroundColor = '#dc3545';
        } else {
            notification.style.backgroundColor = '#17a2b8';
        }

        // Set message
        notification.textContent = message;

        // Add to body
        document.body.appendChild(notification);

        // Remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);

        return notification;
    }
};

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('MORNING EMAIL: Service initialized');
    // Test button removed as requested
});
