/**
 * Email Test Script
 * This script provides a comprehensive way to test email sending functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Email Test Script loaded');
    
    // Create a floating panel for email testing
    const panel = document.createElement('div');
    panel.style.position = 'fixed';
    panel.style.top = '100px';
    panel.style.right = '20px';
    panel.style.width = '300px';
    panel.style.padding = '15px';
    panel.style.backgroundColor = '#f8f9fa';
    panel.style.border = '1px solid #ddd';
    panel.style.borderRadius = '4px';
    panel.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
    panel.style.zIndex = '9999';
    panel.style.display = 'none'; // Hidden by default
    
    // Add panel content
    panel.innerHTML = `
        <h3 style="margin-top: 0; color: #3498db;">Email Test Panel</h3>
        <div style="margin-bottom: 10px;">
            <label for="testEmail" style="display: block; margin-bottom: 5px;">Recipient Email:</label>
            <input type="email" id="testEmail" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 4px;" 
                placeholder="Enter email address" value="p.v.v.s.saidinesh22@ifheindia.org">
        </div>
        <div style="margin-bottom: 10px;">
            <label for="testSubject" style="display: block; margin-bottom: 5px;">Subject:</label>
            <input type="text" id="testSubject" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 4px;" 
                placeholder="Enter subject" value="Test Email from DMS">
        </div>
        <div style="margin-bottom: 15px;">
            <label for="testMessage" style="display: block; margin-bottom: 5px;">Message:</label>
            <textarea id="testMessage" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 4px; height: 80px;" 
                placeholder="Enter message">This is a test email from the Disaster Management System.</textarea>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <button id="sendTestEmailBtn" style="padding: 8px 15px; background-color: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Send Test Email
            </button>
            <button id="sendDirectTestBtn" style="padding: 8px 15px; background-color: #e74c3c; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Send Direct Test
            </button>
        </div>
        <div style="margin-bottom: 10px;">
            <button id="checkEmailLogsBtn" style="width: 100%; padding: 8px 15px; background-color: #27ae60; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Check Email Logs
            </button>
        </div>
        <div id="testEmailStatus" style="margin-top: 10px; font-size: 14px; color: #666;"></div>
    `;
    
    // Add panel to the page
    document.body.appendChild(panel);
    
    // Create toggle button
    const toggleButton = document.createElement('button');
    toggleButton.textContent = 'Email Test';
    toggleButton.style.position = 'fixed';
    toggleButton.style.top = '20px';
    toggleButton.style.right = '20px';
    toggleButton.style.padding = '10px 15px';
    toggleButton.style.backgroundColor = '#3498db';
    toggleButton.style.color = 'white';
    toggleButton.style.border = 'none';
    toggleButton.style.borderRadius = '4px';
    toggleButton.style.cursor = 'pointer';
    toggleButton.style.zIndex = '9999';
    
    // Add toggle button to the page
    document.body.appendChild(toggleButton);
    
    // Toggle panel visibility when button is clicked
    toggleButton.addEventListener('click', function() {
        if (panel.style.display === 'none') {
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    });
    
    // Get elements
    const sendTestEmailBtn = document.getElementById('sendTestEmailBtn');
    const sendDirectTestBtn = document.getElementById('sendDirectTestBtn');
    const checkEmailLogsBtn = document.getElementById('checkEmailLogsBtn');
    const testEmailStatus = document.getElementById('testEmailStatus');
    
    // Add event listener to send test email button
    sendTestEmailBtn.addEventListener('click', function() {
        const email = document.getElementById('testEmail').value;
        const subject = document.getElementById('testSubject').value;
        const message = document.getElementById('testMessage').value;
        
        if (!email || !email.includes('@')) {
            testEmailStatus.textContent = 'Please enter a valid email address';
            testEmailStatus.style.color = '#e74c3c';
            return;
        }
        
        testEmailStatus.textContent = 'Sending test email...';
        testEmailStatus.style.color = '#3498db';
        
        // Create test alert
        const testAlert = {
            id: 'TEST-' + Date.now().toString().slice(-6),
            disasterType: 'Test Alert',
            regions: 'Test Region',
            severity: 'Low',
            message: message || 'This is a test alert message',
            evacuationOrders: 'No evacuation orders - this is a test',
            emergencyContacts: 'Test emergency contacts',
            issuedBy: 'Email Test Panel',
            timestamp: new Date().toISOString()
        };
        
        // Create recipient
        const recipient = {
            email: email,
            name: 'Test Recipient'
        };
        
        // Send test email using DirectEmailService
        if (typeof DirectEmailService !== 'undefined') {
            DirectEmailService.sendAlertEmail(testAlert, [recipient])
                .then(function(result) {
                    testEmailStatus.textContent = 'Test email sent successfully!';
                    testEmailStatus.style.color = '#27ae60';
                    
                    // Log the email
                    logEmailSent({
                        to: email,
                        subject: subject,
                        sentAt: new Date().toISOString(),
                        status: 'sent',
                        provider: 'Gmail (Direct)',
                        alertId: testAlert.id
                    });
                })
                .catch(function(error) {
                    testEmailStatus.textContent = 'Error: ' + error.message;
                    testEmailStatus.style.color = '#e74c3c';
                    
                    // Log the failed email
                    logEmailSent({
                        to: email,
                        subject: subject,
                        sentAt: new Date().toISOString(),
                        status: 'failed',
                        provider: 'Gmail (Direct)',
                        alertId: testAlert.id,
                        error: error.message
                    });
                });
        } else {
            testEmailStatus.textContent = 'DirectEmailService not available';
            testEmailStatus.style.color = '#e74c3c';
        }
    });
    
    // Add event listener to send direct test button
    sendDirectTestBtn.addEventListener('click', function() {
        const email = document.getElementById('testEmail').value;
        
        if (!email || !email.includes('@')) {
            testEmailStatus.textContent = 'Please enter a valid email address';
            testEmailStatus.style.color = '#e74c3c';
            return;
        }
        
        testEmailStatus.textContent = 'Opening direct test email...';
        testEmailStatus.style.color = '#3498db';
        
        // Open test email endpoint directly
        window.open(`http://localhost:3000/api/test-email?email=${encodeURIComponent(email)}`, '_blank');
        
        testEmailStatus.textContent = 'Direct test email initiated';
        testEmailStatus.style.color = '#27ae60';
        
        // Log the email
        logEmailSent({
            to: email,
            subject: 'Direct Test Email',
            sentAt: new Date().toISOString(),
            status: 'sent',
            provider: 'Gmail (Direct)',
            alertId: 'DIRECT-' + Date.now().toString().slice(-6)
        });
    });
    
    // Add event listener to check email logs button
    checkEmailLogsBtn.addEventListener('click', function() {
        window.location.href = 'email-logs.html';
    });
    
    // Function to log sent email
    function logEmailSent(emailData) {
        // Get existing email logs
        const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');
        
        // Add new log entry
        emailLogs.unshift({
            ...emailData,
            id: 'EMAIL-' + Date.now().toString()
        });
        
        // Save back to localStorage
        localStorage.setItem('emailLogs', JSON.stringify(emailLogs));
        
        console.log('Email logged successfully:', emailData);
    }
});
