/**
 * Historical disaster data for the Disaster Management System
 * This file contains sample data of disasters that have occurred worldwide
 * ranging from small to high-level events across different countries and regions
 */

const historicalDisasters = [
    {
        id: "DST-2023-0001",
        type: "Earthquake",
        title: "Turkey-Syria Earthquake",
        location: {
            country: "Turkey/Syria",
            region: "Southeastern Turkey/Northern Syria",
            coordinates: [37.0, 37.0]
        },
        date: "2023-02-06",
        severity: "Critical",
        magnitude: 7.8,
        deaths: 50000,
        injured: 100000,
        description: "A devastating 7.8 magnitude earthquake struck southeastern Turkey and northern Syria, causing widespread destruction and tens of thousands of casualties.",
        affectedAreas: ["Gaziantep", "Aleppo", "Hatay", "Kahramanmaraş"],
        responseEfforts: "International rescue teams, humanitarian aid, emergency shelters",
        imageUrl: "https://example.com/turkey-earthquake.jpg"
    },
    {
        id: "DST-2022-0002",
        type: "Hurricane",
        title: "Hurricane Ian",
        location: {
            country: "United States",
            region: "Florida",
            coordinates: [26.8, -82.0]
        },
        date: "2022-09-28",
        severity: "High",
        magnitude: 5, // Category 5
        deaths: 157,
        injured: 500,
        description: "Hurricane Ian made landfall in Florida as a Category 4 hurricane, causing catastrophic storm surge, winds, and flooding across the state.",
        affectedAreas: ["Fort Myers", "Naples", "Sanibel Island", "Orlando"],
        responseEfforts: "FEMA response, state emergency services, Red Cross shelters",
        imageUrl: "https://example.com/hurricane-ian.jpg"
    },
    {
        id: "DST-2022-0003",
        type: "Flood",
        title: "Pakistan Monsoon Floods",
        location: {
            country: "Pakistan",
            region: "Sindh, Balochistan",
            coordinates: [30.0, 70.0]
        },
        date: "2022-06-14",
        severity: "Critical",
        magnitude: null,
        deaths: 1739,
        injured: 12867,
        description: "Catastrophic flooding in Pakistan following record monsoon rains affected over 33 million people and submerged one-third of the country.",
        affectedAreas: ["Sindh", "Balochistan", "Khyber Pakhtunkhwa", "Punjab"],
        responseEfforts: "UN humanitarian response, international aid, emergency evacuations",
        imageUrl: "https://example.com/pakistan-floods.jpg"
    },
    {
        id: "DST-2023-0004",
        type: "Wildfire",
        title: "Maui Wildfires",
        location: {
            country: "United States",
            region: "Hawaii",
            coordinates: [20.9, -156.6]
        },
        date: "2023-08-08",
        severity: "High",
        magnitude: null,
        deaths: 100,
        injured: 2000,
        description: "Fast-moving wildfires devastated parts of Maui, Hawaii, destroying the historic town of Lahaina and causing widespread evacuation.",
        affectedAreas: ["Lahaina", "Kula", "Upcountry Maui"],
        responseEfforts: "State and federal emergency response, evacuation centers, FEMA assistance",
        imageUrl: "https://example.com/maui-wildfires.jpg"
    },
    {
        id: "DST-2023-0005",
        type: "Tsunami",
        title: "Tonga Volcanic Tsunami",
        location: {
            country: "Tonga",
            region: "Hunga Tonga–Hunga Haʻapai",
            coordinates: [-20.5, -175.4]
        },
        date: "2022-01-15",
        severity: "High",
        magnitude: null,
        deaths: 5,
        injured: 20,
        description: "An underwater volcanic eruption near Tonga triggered tsunami waves affecting Tonga and coastal areas across the Pacific.",
        affectedAreas: ["Tongatapu", "ʻEua", "Haʻapai", "Pacific coastal regions"],
        responseEfforts: "International aid, emergency supplies, communication restoration",
        imageUrl: "https://example.com/tonga-tsunami.jpg"
    },
    {
        id: "DST-2021-0006",
        type: "Cyclone",
        title: "Cyclone Tauktae",
        location: {
            country: "India",
            region: "Western India",
            coordinates: [18.0, 72.0]
        },
        date: "2021-05-17",
        severity: "High",
        magnitude: null,
        deaths: 174,
        injured: 500,
        description: "Extremely severe cyclonic storm Tauktae impacted the west coast of India, causing significant damage and flooding.",
        affectedAreas: ["Gujarat", "Maharashtra", "Kerala", "Karnataka"],
        responseEfforts: "National Disaster Response Force, evacuations, emergency relief",
        imageUrl: "https://example.com/cyclone-tauktae.jpg"
    },
    {
        id: "DST-2022-0007",
        type: "Drought",
        title: "Horn of Africa Drought",
        location: {
            country: "Multiple",
            region: "Horn of Africa",
            coordinates: [5.0, 40.0]
        },
        date: "2022-01-01",
        severity: "Critical",
        magnitude: null,
        deaths: 1000,
        injured: 0,
        description: "Prolonged drought in the Horn of Africa led to widespread food insecurity, affecting millions of people across multiple countries.",
        affectedAreas: ["Somalia", "Ethiopia", "Kenya", "Djibouti"],
        responseEfforts: "UN humanitarian aid, food assistance programs, water supply interventions",
        imageUrl: "https://example.com/horn-africa-drought.jpg"
    },
    {
        id: "DST-2023-0008",
        type: "Landslide",
        title: "Peru Landslides",
        location: {
            country: "Peru",
            region: "Arequipa",
            coordinates: [-16.4, -71.5]
        },
        date: "2023-02-06",
        severity: "Medium",
        magnitude: null,
        deaths: 15,
        injured: 30,
        description: "Heavy rains triggered landslides in southern Peru, destroying homes and infrastructure in several communities.",
        affectedAreas: ["Arequipa", "Moquegua", "Tacna"],
        responseEfforts: "National emergency response, temporary shelters, infrastructure repair",
        imageUrl: "https://example.com/peru-landslides.jpg"
    },
    {
        id: "DST-2022-0009",
        type: "Volcanic Eruption",
        title: "Mount Semeru Eruption",
        location: {
            country: "Indonesia",
            region: "East Java",
            coordinates: [-8.1, 112.9]
        },
        date: "2022-12-04",
        severity: "High",
        magnitude: null,
        deaths: 51,
        injured: 169,
        description: "Mount Semeru volcano in Indonesia erupted, sending ash clouds high into the sky and pyroclastic flows down its slopes.",
        affectedAreas: ["Lumajang", "Malang", "East Java"],
        responseEfforts: "Evacuation, emergency shelters, search and rescue operations",
        imageUrl: "https://example.com/semeru-eruption.jpg"
    },
    {
        id: "DST-2021-0010",
        type: "Tornado",
        title: "US Midwest Tornado Outbreak",
        location: {
            country: "United States",
            region: "Midwest/South",
            coordinates: [36.9, -88.1]
        },
        date: "2021-12-10",
        severity: "Critical",
        magnitude: null,
        deaths: 93,
        injured: 500,
        description: "A devastating tornado outbreak across multiple states in the US Midwest and South, including a powerful EF4 tornado that traveled over 200 miles.",
        affectedAreas: ["Kentucky", "Tennessee", "Arkansas", "Illinois", "Missouri"],
        responseEfforts: "FEMA response, state emergency management, Red Cross disaster relief",
        imageUrl: "https://example.com/midwest-tornadoes.jpg"
    },
    {
        id: "DST-2023-0011",
        type: "Earthquake",
        title: "Morocco Earthquake",
        location: {
            country: "Morocco",
            region: "High Atlas Mountains",
            coordinates: [31.2, -8.4]
        },
        date: "2023-09-08",
        severity: "High",
        magnitude: 6.8,
        deaths: 2900,
        injured: 5500,
        description: "A powerful earthquake struck Morocco's High Atlas Mountains region, causing widespread destruction in rural communities and historic areas.",
        affectedAreas: ["Marrakesh", "Ouarzazate", "Al Haouz", "Taroudant"],
        responseEfforts: "National emergency response, international search and rescue teams, humanitarian aid",
        imageUrl: "https://example.com/morocco-earthquake.jpg"
    },
    {
        id: "DST-2023-0012",
        type: "Flood",
        title: "Libya Floods",
        location: {
            country: "Libya",
            region: "Northeastern Libya",
            coordinates: [32.5, 20.8]
        },
        date: "2023-09-10",
        severity: "Critical",
        magnitude: null,
        deaths: 11300,
        injured: 10000,
        description: "Catastrophic flooding in northeastern Libya following Storm Daniel caused the collapse of two dams, devastating the city of Derna.",
        affectedAreas: ["Derna", "Benghazi", "Al Bayda", "Al Marj"],
        responseEfforts: "International humanitarian response, search and rescue operations, emergency medical aid",
        imageUrl: "https://example.com/libya-floods.jpg"
    },
    {
        id: "DST-2023-0013",
        type: "Flood",
        title: "Central European Floods",
        location: {
            country: "Multiple",
            region: "Central Europe",
            coordinates: [49.8, 15.5]
        },
        date: "2023-09-15",
        severity: "Medium",
        magnitude: null,
        deaths: 23,
        injured: 120,
        description: "Heavy rainfall caused flooding across parts of Central Europe, affecting communities along major rivers and causing significant property damage.",
        affectedAreas: ["Czech Republic", "Poland", "Austria", "Germany"],
        responseEfforts: "Evacuations, emergency flood barriers, humanitarian assistance",
        imageUrl: "https://example.com/central-europe-floods.jpg"
    },
    {
        id: "DST-2022-0014",
        type: "Earthquake",
        title: "Fukushima Earthquake",
        location: {
            country: "Japan",
            region: "Fukushima",
            coordinates: [37.7, 141.0]
        },
        date: "2022-03-16",
        severity: "Medium",
        magnitude: 7.3,
        deaths: 4,
        injured: 225,
        description: "A 7.3 magnitude earthquake struck off the coast of Fukushima, Japan, causing power outages and disrupting transportation services.",
        affectedAreas: ["Fukushima", "Miyagi", "Tokyo"],
        responseEfforts: "Emergency services deployment, infrastructure assessment, temporary shelters",
        imageUrl: "https://example.com/fukushima-earthquake.jpg"
    },
    {
        id: "DST-2021-0015",
        type: "Wildfire",
        title: "Siberian Wildfires",
        location: {
            country: "Russia",
            region: "Siberia",
            coordinates: [60.0, 100.0]
        },
        date: "2021-07-01",
        severity: "High",
        magnitude: null,
        deaths: 10,
        injured: 50,
        description: "Massive wildfires spread across Siberia during an unusually hot summer, burning millions of hectares of forest and creating dangerous air quality conditions.",
        affectedAreas: ["Yakutia", "Krasnoyarsk", "Irkutsk"],
        responseEfforts: "Firefighting operations, evacuations, air quality warnings",
        imageUrl: "https://example.com/siberian-wildfires.jpg"
    },
    {
        id: "DST-2023-0016",
        type: "Heatwave",
        title: "European Heatwave",
        location: {
            country: "Multiple",
            region: "Southern Europe",
            coordinates: [41.9, 12.5]
        },
        date: "2023-07-10",
        severity: "High",
        magnitude: null,
        deaths: 1500,
        injured: 3000,
        description: "An intense heatwave affected Southern Europe with temperatures exceeding 45°C (113°F) in some areas, leading to health emergencies and wildfires.",
        affectedAreas: ["Italy", "Spain", "Greece", "Portugal"],
        responseEfforts: "Cooling centers, public health advisories, emergency medical services",
        imageUrl: "https://example.com/european-heatwave.jpg"
    },
    {
        id: "DST-2022-0017",
        type: "Cyclone",
        title: "Cyclone Batsirai",
        location: {
            country: "Madagascar",
            region: "Eastern Madagascar",
            coordinates: [-21.0, 48.0]
        },
        date: "2022-02-05",
        severity: "High",
        magnitude: null,
        deaths: 121,
        injured: 210,
        description: "Cyclone Batsirai made landfall in eastern Madagascar as a powerful tropical cyclone, causing widespread destruction to homes and infrastructure.",
        affectedAreas: ["Mananjary", "Fianarantsoa", "Antananarivo"],
        responseEfforts: "International humanitarian aid, emergency shelters, food distribution",
        imageUrl: "https://example.com/cyclone-batsirai.jpg"
    },
    {
        id: "DST-2021-0018",
        type: "Landslide",
        title: "Atami Landslide",
        location: {
            country: "Japan",
            region: "Shizuoka Prefecture",
            coordinates: [35.1, 139.1]
        },
        date: "2021-07-03",
        severity: "Medium",
        magnitude: null,
        deaths: 27,
        injured: 14,
        description: "Heavy rainfall triggered a large mudslide in the coastal city of Atami, sweeping away homes and burying streets in mud and debris.",
        affectedAreas: ["Atami", "Shizuoka"],
        responseEfforts: "Search and rescue operations, evacuation centers, disaster relief",
        imageUrl: "https://example.com/atami-landslide.jpg"
    },
    {
        id: "DST-2023-0019",
        type: "Flood",
        title: "New Zealand Auckland Floods",
        location: {
            country: "New Zealand",
            region: "Auckland",
            coordinates: [-36.8, 174.8]
        },
        date: "2023-01-27",
        severity: "Medium",
        magnitude: null,
        deaths: 4,
        injured: 20,
        description: "Record rainfall in Auckland caused severe flooding, leading to evacuations, airport closures, and significant damage to homes and infrastructure.",
        affectedAreas: ["Auckland", "Northland", "Waikato"],
        responseEfforts: "Emergency declarations, evacuations, infrastructure repairs",
        imageUrl: "https://example.com/auckland-floods.jpg"
    },
    {
        id: "DST-2022-0020",
        type: "Drought",
        title: "Chile Megadrought",
        location: {
            country: "Chile",
            region: "Central Chile",
            coordinates: [-33.4, -70.6]
        },
        date: "2022-01-01",
        severity: "High",
        magnitude: null,
        deaths: 0,
        injured: 0,
        description: "Chile's ongoing megadrought intensified, marking over a decade of below-average rainfall, severely impacting agriculture and water supplies.",
        affectedAreas: ["Santiago", "Valparaíso", "O'Higgins", "Maule"],
        responseEfforts: "Water rationing, agricultural subsidies, infrastructure for water security",
        imageUrl: "https://example.com/chile-drought.jpg"
    },
    {
        id: "DST-2021-0021",
        type: "Volcanic Eruption",
        title: "La Palma Volcano Eruption",
        location: {
            country: "Spain",
            region: "Canary Islands",
            coordinates: [28.6, -17.8]
        },
        date: "2021-09-19",
        severity: "Medium",
        magnitude: null,
        deaths: 0,
        injured: 7,
        description: "The Cumbre Vieja volcano on La Palma island erupted, producing lava flows that destroyed thousands of buildings and forced mass evacuations.",
        affectedAreas: ["La Palma", "Canary Islands"],
        responseEfforts: "Evacuations, emergency housing, financial assistance for affected residents",
        imageUrl: "https://example.com/la-palma-volcano.jpg"
    },
    {
        id: "DST-2023-0022",
        type: "Tornado",
        title: "Mississippi Tornado",
        location: {
            country: "United States",
            region: "Mississippi",
            coordinates: [33.8, -90.4]
        },
        date: "2023-03-24",
        severity: "High",
        magnitude: null,
        deaths: 26,
        injured: 100,
        description: "A powerful tornado tore through western Mississippi, causing catastrophic damage to homes and businesses in several communities.",
        affectedAreas: ["Rolling Fork", "Silver City", "Amory"],
        responseEfforts: "FEMA assistance, Red Cross shelters, state emergency response",
        imageUrl: "https://example.com/mississippi-tornado.jpg"
    },
    {
        id: "DST-2022-0023",
        type: "Avalanche",
        title: "Dolomites Glacier Collapse",
        location: {
            country: "Italy",
            region: "Dolomites",
            coordinates: [46.4, 11.8]
        },
        date: "2022-07-03",
        severity: "Medium",
        magnitude: null,
        deaths: 11,
        injured: 8,
        description: "A large chunk of the Marmolada glacier in the Italian Dolomites collapsed, triggering an avalanche of ice, rock, and debris that struck hikers on a popular trail.",
        affectedAreas: ["Marmolada", "Trentino", "Veneto"],
        responseEfforts: "Mountain rescue operations, helicopter evacuations, area closures",
        imageUrl: "https://example.com/dolomites-avalanche.jpg"
    },
    {
        id: "DST-2021-0024",
        type: "Flood",
        title: "Henan Floods",
        location: {
            country: "China",
            region: "Henan Province",
            coordinates: [34.7, 113.6]
        },
        date: "2021-07-20",
        severity: "Critical",
        magnitude: null,
        deaths: 302,
        injured: 815,
        description: "Extreme rainfall in China's Henan province caused catastrophic flooding, with a year's worth of rain falling in just three days in some areas.",
        affectedAreas: ["Zhengzhou", "Xinxiang", "Hebi"],
        responseEfforts: "Military rescue operations, emergency evacuations, disaster relief funds",
        imageUrl: "https://example.com/henan-floods.jpg"
    },
    {
        id: "DST-2023-0025",
        type: "Earthquake",
        title: "Kahramanmaraş Aftershock",
        location: {
            country: "Turkey",
            region: "Kahramanmaraş",
            coordinates: [37.6, 37.0]
        },
        date: "2023-02-20",
        severity: "Medium",
        magnitude: 6.3,
        deaths: 6,
        injured: 294,
        description: "A 6.3 magnitude aftershock struck southern Turkey two weeks after the devastating 7.8 magnitude earthquake, causing additional building collapses and injuries.",
        affectedAreas: ["Hatay", "Kahramanmaraş", "Antakya"],
        responseEfforts: "Ongoing search and rescue, medical aid, temporary shelters",
        imageUrl: "https://example.com/turkey-aftershock.jpg"
    },
    {
        id: "DST-2022-0026",
        type: "Typhoon",
        title: "Typhoon Noru",
        location: {
            country: "Philippines",
            region: "Luzon",
            coordinates: [15.5, 121.0]
        },
        date: "2022-09-25",
        severity: "High",
        magnitude: null,
        deaths: 12,
        injured: 60,
        description: "Typhoon Noru (locally named Karding) rapidly intensified before making landfall in the Philippines, bringing strong winds and heavy rainfall.",
        affectedAreas: ["Quezon", "Aurora", "Nueva Ecija", "Bulacan"],
        responseEfforts: "Preemptive evacuations, emergency response, relief operations",
        imageUrl: "https://example.com/typhoon-noru.jpg"
    },
    {
        id: "DST-2021-0027",
        type: "Wildfire",
        title: "Dixie Fire",
        location: {
            country: "United States",
            region: "California",
            coordinates: [40.0, -121.2]
        },
        date: "2021-07-13",
        severity: "High",
        magnitude: null,
        deaths: 1,
        injured: 6,
        description: "The Dixie Fire became the second-largest wildfire in California history, burning nearly 1 million acres and destroying the historic town of Greenville.",
        affectedAreas: ["Butte County", "Plumas County", "Lassen County", "Shasta County", "Tehama County"],
        responseEfforts: "Massive firefighting operation, evacuations, disaster declarations",
        imageUrl: "https://example.com/dixie-fire.jpg"
    },
    {
        id: "DST-2023-0028",
        type: "Cyclone",
        title: "Cyclone Freddy",
        location: {
            country: "Multiple",
            region: "Southeast Africa",
            coordinates: [-18.7, 35.5]
        },
        date: "2023-02-19",
        severity: "Critical",
        magnitude: null,
        deaths: 1400,
        injured: 2300,
        description: "Cyclone Freddy became one of the longest-lasting tropical cyclones on record, making multiple landfalls in Madagascar, Mozambique, and Malawi over several weeks.",
        affectedAreas: ["Mozambique", "Malawi", "Madagascar", "Zimbabwe"],
        responseEfforts: "International humanitarian response, search and rescue, emergency shelter",
        imageUrl: "https://example.com/cyclone-freddy.jpg"
    },
    {
        id: "DST-2022-0029",
        type: "Flood",
        title: "South African Floods",
        location: {
            country: "South Africa",
            region: "KwaZulu-Natal",
            coordinates: [-29.8, 31.0]
        },
        date: "2022-04-11",
        severity: "High",
        magnitude: null,
        deaths: 435,
        injured: 600,
        description: "Catastrophic flooding in South Africa's KwaZulu-Natal province caused widespread destruction to homes, businesses, and infrastructure.",
        affectedAreas: ["Durban", "Pietermaritzburg", "Port Shepstone"],
        responseEfforts: "National disaster declaration, military deployment, humanitarian aid",
        imageUrl: "https://example.com/south-africa-floods.jpg"
    },
    {
        id: "DST-2021-0030",
        type: "Earthquake",
        title: "Haiti Earthquake",
        location: {
            country: "Haiti",
            region: "Tiburon Peninsula",
            coordinates: [18.4, -73.5]
        },
        date: "2021-08-14",
        severity: "Critical",
        magnitude: 7.2,
        deaths: 2248,
        injured: 12763,
        description: "A powerful 7.2 magnitude earthquake struck Haiti's Tiburon Peninsula, causing widespread destruction in a country still recovering from previous disasters.",
        affectedAreas: ["Les Cayes", "Jérémie", "Petit-Trou-de-Nippes"],
        responseEfforts: "International search and rescue, medical aid, humanitarian assistance",
        imageUrl: "https://example.com/haiti-earthquake.jpg"
    },
    {
        id: "DST-2023-0031",
        type: "Landslide",
        title: "Cameroon Landslide",
        location: {
            country: "Cameroon",
            region: "Yaoundé",
            coordinates: [3.9, 11.5]
        },
        date: "2023-11-27",
        severity: "Medium",
        magnitude: null,
        deaths: 27,
        injured: 14,
        description: "Heavy rainfall triggered a landslide in Cameroon's capital, Yaoundé, burying homes in the Mbankolo neighborhood.",
        affectedAreas: ["Yaoundé", "Mbankolo"],
        responseEfforts: "Rescue operations, emergency assistance, temporary relocation",
        imageUrl: "https://example.com/cameroon-landslide.jpg"
    },
    {
        id: "DST-2022-0032",
        type: "Drought",
        title: "Angola Drought",
        location: {
            country: "Angola",
            region: "Southern Angola",
            coordinates: [-15.0, 15.0]
        },
        date: "2022-03-01",
        severity: "High",
        magnitude: null,
        deaths: 15,
        injured: 0,
        description: "Severe drought conditions in southern Angola led to crop failures, water shortages, and food insecurity, affecting millions of people.",
        affectedAreas: ["Cunene", "Huíla", "Namibe", "Cuando Cubango"],
        responseEfforts: "UN humanitarian aid, water distribution, food assistance programs",
        imageUrl: "https://example.com/angola-drought.jpg"
    },
    {
        id: "DST-2021-0033",
        type: "Flood",
        title: "Malaysia Floods",
        location: {
            country: "Malaysia",
            region: "Peninsular Malaysia",
            coordinates: [3.1, 101.7]
        },
        date: "2021-12-18",
        severity: "High",
        magnitude: null,
        deaths: 54,
        injured: 200,
        description: "Torrential rains caused severe flooding across eight Malaysian states, displacing tens of thousands of people and damaging property.",
        affectedAreas: ["Selangor", "Pahang", "Kelantan", "Terengganu"],
        responseEfforts: "Military evacuations, relief centers, emergency supplies distribution",
        imageUrl: "https://example.com/malaysia-floods.jpg"
    },
    {
        id: "DST-2023-0034",
        type: "Heatwave",
        title: "India Heatwave",
        location: {
            country: "India",
            region: "Northern India",
            coordinates: [28.6, 77.2]
        },
        date: "2023-06-15",
        severity: "High",
        magnitude: null,
        deaths: 96,
        injured: 450,
        description: "An intense heatwave swept across northern India with temperatures exceeding 49°C (120°F) in some areas, causing heat-related illnesses and deaths.",
        affectedAreas: ["Delhi", "Uttar Pradesh", "Rajasthan", "Punjab", "Haryana"],
        responseEfforts: "Cooling centers, water distribution, public health advisories",
        imageUrl: "https://example.com/india-heatwave.jpg"
    },
    {
        id: "DST-2022-0035",
        type: "Tornado",
        title: "Czech Republic Tornado",
        location: {
            country: "Czech Republic",
            region: "South Moravia",
            coordinates: [48.8, 17.1]
        },
        date: "2022-06-24",
        severity: "Medium",
        magnitude: null,
        deaths: 6,
        injured: 200,
        description: "A rare and powerful tornado struck several villages in the South Moravia region of the Czech Republic, causing extensive damage to buildings and infrastructure.",
        affectedAreas: ["Hodonín", "Břeclav"],
        responseEfforts: "Emergency response, temporary housing, reconstruction aid",
        imageUrl: "https://example.com/czech-tornado.jpg"
    },
    {
        id: "DST-2021-0036",
        type: "Tsunami",
        title: "Indonesia Semeru Tsunami",
        location: {
            country: "Indonesia",
            region: "East Java",
            coordinates: [-8.1, 112.9]
        },
        date: "2021-12-04",
        severity: "Medium",
        magnitude: null,
        deaths: 51,
        injured: 169,
        description: "The eruption of Mount Semeru volcano triggered localized tsunamis and lahars (volcanic mudflows) that affected nearby communities in East Java.",
        affectedAreas: ["Lumajang", "Malang"],
        responseEfforts: "Evacuation, emergency relief, disaster response teams",
        imageUrl: "https://example.com/semeru-tsunami.jpg"
    },
    {
        id: "DST-2023-0037",
        type: "Wildfire",
        title: "Canadian Wildfires",
        location: {
            country: "Canada",
            region: "Multiple Provinces",
            coordinates: [53.7, -113.7]
        },
        date: "2023-05-01",
        severity: "Critical",
        magnitude: null,
        deaths: 6,
        injured: 30,
        description: "Record-breaking wildfires across Canada burned millions of hectares, forcing evacuations and creating hazardous air quality conditions across North America.",
        affectedAreas: ["Alberta", "British Columbia", "Nova Scotia", "Quebec", "Ontario"],
        responseEfforts: "Mass evacuations, international firefighting assistance, air quality advisories",
        imageUrl: "https://example.com/canada-wildfires.jpg"
    },
    {
        id: "DST-2022-0038",
        type: "Earthquake",
        title: "Afghanistan Earthquake",
        location: {
            country: "Afghanistan",
            region: "Khost Province",
            coordinates: [33.0, 69.5]
        },
        date: "2022-06-22",
        severity: "High",
        magnitude: 5.9,
        deaths: 1163,
        injured: 6000,
        description: "A 5.9 magnitude earthquake struck eastern Afghanistan, causing widespread destruction in remote, mountainous areas with vulnerable housing structures.",
        affectedAreas: ["Khost", "Paktika"],
        responseEfforts: "International humanitarian aid, search and rescue, emergency medical care",
        imageUrl: "https://example.com/afghanistan-earthquake.jpg"
    },
    {
        id: "DST-2021-0039",
        type: "Flood",
        title: "Belgium Floods",
        location: {
            country: "Belgium",
            region: "Wallonia",
            coordinates: [50.6, 5.6]
        },
        date: "2021-07-14",
        severity: "High",
        magnitude: null,
        deaths: 42,
        injured: 100,
        description: "Catastrophic flooding in Belgium's Wallonia region following heavy rainfall, with rivers overflowing and causing extensive damage to towns and infrastructure.",
        affectedAreas: ["Liège", "Verviers", "Pepinster", "Spa"],
        responseEfforts: "Military assistance, emergency evacuations, EU solidarity fund",
        imageUrl: "https://example.com/belgium-floods.jpg"
    },
    {
        id: "DST-2023-0040",
        type: "Cyclone",
        title: "Cyclone Mocha",
        location: {
            country: "Myanmar",
            region: "Rakhine State",
            coordinates: [20.1, 92.9]
        },
        date: "2023-05-14",
        severity: "High",
        magnitude: null,
        deaths: 145,
        injured: 300,
        description: "Cyclone Mocha made landfall in Myanmar's Rakhine State as a Category 5 equivalent storm, causing widespread destruction in vulnerable communities.",
        affectedAreas: ["Sittwe", "Kyaukpyu", "Cox's Bazar"],
        responseEfforts: "Humanitarian aid, emergency shelter, food distribution",
        imageUrl: "https://example.com/cyclone-mocha.jpg"
    },
    {
        id: "DST-2023-0041",
        type: "Earthquake",
        title: "Northern California Earthquake",
        location: {
            country: "United States",
            region: "California",
            coordinates: [40.5, -124.2]
        },
        date: "2023-12-20",
        severity: "Low",
        magnitude: 4.5,
        deaths: 0,
        injured: 3,
        description: "A moderate earthquake struck offshore of Northern California, causing minor damage to some structures and brief power outages in coastal communities.",
        affectedAreas: ["Humboldt County", "Eureka", "Ferndale"],
        responseEfforts: "Infrastructure assessment, utility repairs, precautionary checks",
        imageUrl: "https://example.com/norcal-earthquake.jpg"
    },
    {
        id: "DST-2022-0042",
        type: "Flood",
        title: "Slovenia Flash Floods",
        location: {
            country: "Slovenia",
            region: "Central Slovenia",
            coordinates: [46.1, 14.5]
        },
        date: "2022-09-16",
        severity: "Low",
        magnitude: null,
        deaths: 0,
        injured: 2,
        description: "Localized flash flooding affected several communities in central Slovenia following intense rainfall, causing minor property damage and temporary road closures.",
        affectedAreas: ["Ljubljana", "Kamnik", "Domžale"],
        responseEfforts: "Local emergency response, drainage operations, temporary traffic diversions",
        imageUrl: "https://example.com/slovenia-floods.jpg"
    },
    {
        id: "DST-2021-0043",
        type: "Wildfire",
        title: "Costa Rican Forest Fire",
        location: {
            country: "Costa Rica",
            region: "Guanacaste",
            coordinates: [10.6, -85.4]
        },
        date: "2021-03-10",
        severity: "Low",
        magnitude: null,
        deaths: 0,
        injured: 0,
        description: "A small wildfire in Costa Rica's Guanacaste province burned through dry forest areas but was contained before causing significant damage to protected areas or communities.",
        affectedAreas: ["Santa Rosa National Park", "Guanacaste Conservation Area"],
        responseEfforts: "Firefighting operations, preventive measures, ecological monitoring",
        imageUrl: "https://example.com/costa-rica-fire.jpg"
    },
    {
        id: "DST-2023-0044",
        type: "Landslide",
        title: "Norwegian Coastal Landslide",
        location: {
            country: "Norway",
            region: "Western Norway",
            coordinates: [60.4, 5.3]
        },
        date: "2023-10-05",
        severity: "Low",
        magnitude: null,
        deaths: 0,
        injured: 0,
        description: "A small landslide occurred along Norway's western coast following heavy rainfall, causing minor damage to a coastal road but no casualties.",
        affectedAreas: ["Bergen", "Hordaland"],
        responseEfforts: "Road closure, geological assessment, preventive measures",
        imageUrl: "https://example.com/norway-landslide.jpg"
    },
    {
        id: "DST-2022-0045",
        type: "Storm",
        title: "Uruguay Thunderstorms",
        location: {
            country: "Uruguay",
            region: "Southern Uruguay",
            coordinates: [-34.8, -56.2]
        },
        date: "2022-11-12",
        severity: "Low",
        magnitude: null,
        deaths: 0,
        injured: 5,
        description: "A series of thunderstorms brought strong winds and localized flooding to parts of southern Uruguay, causing minor damage to structures and temporary power outages.",
        affectedAreas: ["Montevideo", "Canelones", "Maldonado"],
        responseEfforts: "Emergency services response, power restoration, debris clearing",
        imageUrl: "https://example.com/uruguay-storms.jpg"
    }
];

// Function to get disasters by type
function getDisastersByType(type) {
    return historicalDisasters.filter(disaster => disaster.type === type);
}

// Function to get disasters by country
function getDisastersByCountry(country) {
    return historicalDisasters.filter(disaster => disaster.location.country.includes(country));
}

// Function to get disasters by date range
function getDisastersByDateRange(startDate, endDate) {
    return historicalDisasters.filter(disaster => {
        const disasterDate = new Date(disaster.date);
        return disasterDate >= new Date(startDate) && disasterDate <= new Date(endDate);
    });
}

// Function to get disasters by severity
function getDisastersBySeverity(severity) {
    return historicalDisasters.filter(disaster => disaster.severity === severity);
}

// Function to get disaster by ID
function getDisasterById(id) {
    return historicalDisasters.find(disaster => disaster.id === id);
}

// Function to get total casualties by disaster type
function getTotalCasualtiesByType() {
    const result = {};

    historicalDisasters.forEach(disaster => {
        if (!result[disaster.type]) {
            result[disaster.type] = {
                deaths: 0,
                injured: 0
            };
        }

        result[disaster.type].deaths += disaster.deaths || 0;
        result[disaster.type].injured += disaster.injured || 0;
    });

    return result;
}

// Function to get disaster count by year
function getDisasterCountByYear() {
    const result = {};

    historicalDisasters.forEach(disaster => {
        const year = disaster.date.split('-')[0];

        if (!result[year]) {
            result[year] = 0;
        }

        result[year]++;
    });

    return result;
}

// Function to get disaster count by type
function getDisasterCountByType() {
    const result = {};

    historicalDisasters.forEach(disaster => {
        if (!result[disaster.type]) {
            result[disaster.type] = 0;
        }

        result[disaster.type]++;
    });

    return result;
}
