/**
 * Force Real Email Mode - Aggressive Version
 * This script forcibly enables real email mode and removes simulation mode banners
 */

// Execute immediately when loaded
(function() {
    console.log('AGGRESSIVE REAL EMAIL MODE: Forcibly enabling real email mode');
    
    // Force real email mode in EmailService
    if (typeof EmailService !== 'undefined') {
        // Override configuration
        EmailService.config.useRealEmails = true;
        EmailService.config.useBackendServer = true;
        
        // Override the init method to always use real emails
        const originalInit = EmailService.init;
        EmailService.init = function() {
            this.config.useRealEmails = true;
            this.config.useBackendServer = true;
            
            // Call original init
            if (originalInit) originalInit.call(this);
            
            console.log('Email service forcibly configured for real emails');
        };
        
        // Override the showNotification method to prevent simulation mode notifications
        const originalShowNotification = EmailService.showNotification;
        EmailService.showNotification = function(message, type, duration) {
            // Replace simulation mode messages with real email messages
            if (message && message.includes && message.includes('SIMULATION MODE')) {
                message = 'REAL EMAIL MODE: Emails will be sent to actual recipients';
                type = 'success';
            }
            
            // Call original method
            return originalShowNotification.call(this, message, type, duration);
        };
        
        // Override the sendAlertEmail method to always use real emails
        const originalSendAlertEmail = EmailService.sendAlertEmail;
        EmailService.sendAlertEmail = function(recipient, alert, callback) {
            // Force real email mode
            this.config.useRealEmails = true;
            this.config.useBackendServer = true;
            
            // Call original method
            return originalSendAlertEmail.call(this, recipient, alert, callback);
        };
        
        // Override the sendAlertToAllUsers method to always use real emails
        const originalSendAlertToAllUsers = EmailService.sendAlertToAllUsers;
        EmailService.sendAlertToAllUsers = function(alert, additionalRecipients) {
            // Force real email mode
            this.config.useRealEmails = true;
            this.config.useBackendServer = true;
            
            // Call original method
            return originalSendAlertToAllUsers.call(this, alert, additionalRecipients);
        };
        
        console.log('Email service methods overridden to force real email mode');
    }
    
    // Function to remove simulation mode banners
    function removeSimulationBanners() {
        // Find all elements that might be simulation mode banners
        const elements = document.querySelectorAll('div');
        
        for (let i = 0; i < elements.length; i++) {
            const el = elements[i];
            
            // Check if it's a notification
            if (el.classList.contains('notification') || el.classList.contains('notification-container')) {
                // Check if it contains simulation mode text
                if (el.textContent && el.textContent.includes('SIMULATION MODE')) {
                    console.log('Removing simulation mode banner:', el);
                    el.style.display = 'none';
                    el.style.visibility = 'hidden';
                    el.style.opacity = '0';
                    el.style.height = '0';
                    el.style.overflow = 'hidden';
                    
                    // Try to remove it from the DOM
                    if (el.parentNode) {
                        el.parentNode.removeChild(el);
                    }
                }
            }
            
            // Check if it has a blue background (simulation mode banner)
            const style = window.getComputedStyle(el);
            if (style.backgroundColor === 'rgb(23, 162, 184)' || style.backgroundColor === '#17a2b8') {
                console.log('Removing blue banner:', el);
                el.style.display = 'none';
                el.style.visibility = 'hidden';
                el.style.opacity = '0';
                el.style.height = '0';
                el.style.overflow = 'hidden';
                
                // Try to remove it from the DOM
                if (el.parentNode) {
                    el.parentNode.removeChild(el);
                }
            }
        }
    }
    
    // Remove simulation banners immediately
    removeSimulationBanners();
    
    // Continue checking for and removing simulation banners
    setInterval(removeSimulationBanners, 500);
    
    // Also remove banners when DOM changes
    const observer = new MutationObserver(function(mutations) {
        removeSimulationBanners();
    });
    
    // Start observing the document
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
    
    // Override localStorage to ensure useRealEmails is always true
    const originalSetItem = localStorage.setItem;
    localStorage.setItem = function(key, value) {
        // If trying to set email configuration, ensure real emails are enabled
        if (key === 'emailConfig' || key === 'EmailService.config') {
            try {
                const config = JSON.parse(value);
                config.useRealEmails = true;
                config.useBackendServer = true;
                value = JSON.stringify(config);
            } catch (e) {
                console.error('Error parsing email config:', e);
            }
        }
        
        // Call original method
        return originalSetItem.call(this, key, value);
    };
    
    console.log('Aggressive real email mode enabled');
})();
