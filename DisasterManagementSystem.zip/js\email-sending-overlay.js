/**
 * Email Sending Overlay
 * A simple overlay to show when emails are being sent
 */

const EmailSendingOverlay = {
    /**
     * Show the email sending overlay
     * @returns {HTMLElement} - The overlay element
     */
    show: function() {
        // Remove any existing overlay first
        this.hide();
        
        // Create the overlay
        const overlay = document.createElement('div');
        overlay.id = 'emailSendingOverlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        overlay.style.display = 'flex';
        overlay.style.justifyContent = 'center';
        overlay.style.alignItems = 'center';
        overlay.style.zIndex = '9999';
        
        // Create the content container
        const content = document.createElement('div');
        content.style.backgroundColor = '#fff';
        content.style.padding = '20px';
        content.style.borderRadius = '5px';
        content.style.display = 'flex';
        content.style.alignItems = 'center';
        content.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        
        // Create the spinner
        const spinner = document.createElement('div');
        spinner.style.width = '24px';
        spinner.style.height = '24px';
        spinner.style.border = '3px solid #f3f3f3';
        spinner.style.borderTop = '3px solid #3498db';
        spinner.style.borderRadius = '50%';
        spinner.style.marginRight = '10px';
        spinner.style.animation = 'spin 1s linear infinite';
        
        // Add the spin animation
        const style = document.createElement('style');
        style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
        document.head.appendChild(style);
        
        // Create the message
        const message = document.createElement('span');
        message.textContent = 'Sending email alerts...';
        message.style.fontFamily = 'Arial, sans-serif';
        
        // Assemble the overlay
        content.appendChild(spinner);
        content.appendChild(message);
        overlay.appendChild(content);
        document.body.appendChild(overlay);
        
        return overlay;
    },
    
    /**
     * Hide the email sending overlay
     */
    hide: function() {
        const overlay = document.getElementById('emailSendingOverlay');
        if (overlay) {
            overlay.remove();
        }
    }
};
