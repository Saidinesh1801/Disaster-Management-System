/**
 * Real-Time Email Service
 * A simplified email service that focuses on reliable, real-time email delivery
 */

const RealTimeEmailService = {
    // API configuration
    apiUrl: 'http://localhost:3001',

    /**
     * Send a test email
     * @param {string} email - Recipient email address
     * @returns {Promise} - Promise that resolves when the email is sent
     */
    sendTestEmail: function(email) {
        console.log('REAL-TIME EMAIL: Sending test email to', email);

        // Show sending notification
        this.showNotification('Sending test email...', 'info');

        // Send the request
        return fetch(`${this.apiUrl}/send-test-email?email=${encodeURIComponent(email)}`)
            .then(response => {
                console.log('REAL-TIME EMAIL: Test email response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('REAL-TIME EMAIL: Test email response data:', data);

                if (data.success) {
                    // Show success notification
                    this.showNotification(`Test email sent to ${data.details.recipient}`, 'success');

                    // Log test email in localStorage
                    this.logEmailSent({
                        to: data.details.recipient,
                        subject: 'Test Email from Disaster Management System',
                        sentAt: new Date().toISOString(),
                        status: 'sent',
                        provider: 'Gmail (Direct)',
                        alertId: 'TEST-' + Date.now().toString().slice(-6)
                    });

                    return data;
                } else {
                    throw new Error(data.message || 'Failed to send test email');
                }
            })
            .catch(error => {
                console.error('REAL-TIME EMAIL: Error sending test email:', error);

                // Show error notification
                this.showNotification(`Error sending test email: ${error.message}`, 'error');

                // Log failed email
                this.logEmailSent({
                    to: email,
                    subject: 'Test Email from Disaster Management System',
                    sentAt: new Date().toISOString(),
                    status: 'failed',
                    provider: 'Gmail (Direct)',
                    alertId: 'TEST-' + Date.now().toString().slice(-6),
                    error: error.message
                });

                throw error;
            });
    },

    /**
     * Send an alert email
     * @param {Object} alert - The alert object
     * @param {Object} recipient - The recipient object with email and name
     * @returns {Promise} - Promise that resolves when the email is sent
     */
    sendAlertEmail: function(alert, recipient) {
        console.log('REAL-TIME EMAIL: Sending alert email to', recipient.email);
        console.log('REAL-TIME EMAIL: Alert data:', alert);

        // Show sending notification
        this.showNotification(`Sending alert email to ${recipient.email}...`, 'info');

        // Send the request
        return fetch(`${this.apiUrl}/send-alert-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                recipient: {
                    email: recipient.email,
                    fullname: recipient.name || recipient.fullname || ''
                },
                alert: {
                    id: alert.id || 'ALT-' + Date.now(),
                    disasterType: alert.disasterType || 'Emergency Alert',
                    regions: alert.location || alert.regions || alert.affectedAreas || 'All Regions',
                    severity: alert.severity || 'High',
                    datetime: alert.timestamp || new Date().toISOString(),
                    message: alert.description || alert.message || 'Emergency alert notification',
                    issuedBy: alert.reportedBy || alert.issuedBy || 'Disaster Management System',
                    evacuationOrders: alert.evacuationOrders || 'Follow local authority instructions',
                    emergencyContacts: alert.emergencyContacts || 'Emergency Services: 911'
                }
            })
        })
        .then(response => {
            console.log('REAL-TIME EMAIL: Alert email response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('REAL-TIME EMAIL: Alert email response data:', data);

            if (data.success) {
                // Show success notification
                this.showNotification(`Alert email sent to ${recipient.email}`, 'success');

                // Log email in localStorage
                this.logEmailSent({
                    to: recipient.email,
                    subject: `${alert.disasterType} Alert for ${alert.location || alert.regions || alert.affectedAreas || 'All Regions'}`,
                    sentAt: new Date().toISOString(),
                    status: 'sent',
                    provider: 'Gmail (Direct)',
                    alertId: alert.id
                });

                return data;
            } else {
                throw new Error(data.message || 'Failed to send alert email');
            }
        })
        .catch(error => {
            console.error('REAL-TIME EMAIL: Error sending alert email:', error);

            // Show error notification
            this.showNotification(`Error sending alert email: ${error.message}`, 'error');

            // Log failed email
            this.logEmailSent({
                to: recipient.email,
                subject: `${alert.disasterType} Alert for ${alert.location || alert.regions || alert.affectedAreas || 'All Regions'}`,
                sentAt: new Date().toISOString(),
                status: 'failed',
                provider: 'Gmail (Direct)',
                alertId: alert.id,
                error: error.message
            });

            throw error;
        });
    },

    /**
     * Send alert emails to multiple recipients
     * @param {Object} alert - The alert object
     * @param {Array} recipients - Array of recipient objects with email and name
     * @returns {Promise} - Promise that resolves when the emails are sent
     */
    sendBulkAlerts: function(alert, recipients) {
        console.log('REAL-TIME EMAIL: Sending bulk alert emails to', recipients.length, 'recipients');
        console.log('REAL-TIME EMAIL: Alert data:', alert);

        // Show sending notification
        this.showNotification(`Sending alert emails to ${recipients.length} recipients...`, 'info');

        // Send the request
        return fetch(`${this.apiUrl}/send-bulk-alerts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                recipients: recipients.map(recipient => ({
                    email: recipient.email,
                    fullname: recipient.name || recipient.fullname || ''
                })),
                alert: {
                    id: alert.id || 'ALT-' + Date.now(),
                    disasterType: alert.disasterType || 'Emergency Alert',
                    regions: alert.location || alert.regions || alert.affectedAreas || 'All Regions',
                    severity: alert.severity || 'High',
                    datetime: alert.timestamp || new Date().toISOString(),
                    message: alert.description || alert.message || 'Emergency alert notification',
                    issuedBy: alert.reportedBy || alert.issuedBy || 'Disaster Management System',
                    evacuationOrders: alert.evacuationOrders || 'Follow local authority instructions',
                    emergencyContacts: alert.emergencyContacts || 'Emergency Services: 911'
                }
            })
        })
        .then(response => {
            console.log('REAL-TIME EMAIL: Bulk alert emails response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('REAL-TIME EMAIL: Bulk alert emails response data:', data);

            if (data.success) {
                // Show success notification
                this.showNotification(`Alert emails are being sent to ${recipients.length} recipients`, 'success');

                // Log emails in localStorage
                recipients.forEach(recipient => {
                    this.logEmailSent({
                        to: recipient.email,
                        subject: `${alert.disasterType} Alert for ${alert.location || alert.regions || alert.affectedAreas || 'All Regions'}`,
                        sentAt: new Date().toISOString(),
                        status: 'sent',
                        provider: 'Gmail (Direct)',
                        alertId: alert.id
                    });
                });

                return data;
            } else {
                throw new Error(data.message || 'Failed to send bulk alert emails');
            }
        })
        .catch(error => {
            console.error('REAL-TIME EMAIL: Error sending bulk alert emails:', error);

            // Show error notification
            this.showNotification(`Error sending bulk alert emails: ${error.message}`, 'error');

            throw error;
        });
    },

    /**
     * Log sent email in localStorage
     * @param {Object} emailData - Email data to log
     */
    logEmailSent: function(emailData) {
        console.log('REAL-TIME EMAIL: Logging email to localStorage:', emailData);

        // Get existing email logs
        const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');

        // Add new log entry with unique ID
        emailLogs.unshift({
            ...emailData,
            id: 'EMAIL-' + Date.now().toString()
        });

        // Save back to localStorage
        localStorage.setItem('emailLogs', JSON.stringify(emailLogs));

        console.log('REAL-TIME EMAIL: Email logged successfully. Total logs:', emailLogs.length);
    },

    /**
     * Show a notification message
     * @param {string} message - The message to display
     * @param {string} type - The type of notification (success, error, info)
     * @param {number} duration - How long to show the notification in ms
     */
    showNotification: function(message, type = 'info', duration = 5000) {
        // Create notification element
        const notification = document.createElement('div');
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.padding = '15px 20px';
        notification.style.borderRadius = '4px';
        notification.style.color = 'white';
        notification.style.fontWeight = 'bold';
        notification.style.zIndex = '9999';
        notification.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';

        // Set background color based on type
        if (type === 'success') {
            notification.style.backgroundColor = '#28a745';
        } else if (type === 'error') {
            notification.style.backgroundColor = '#dc3545';
        } else {
            notification.style.backgroundColor = '#17a2b8';
        }

        // Set message
        notification.textContent = message;

        // Add to body
        document.body.appendChild(notification);

        // Remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, duration);

        return notification;
    }
};

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('REAL-TIME EMAIL: Service initialized');
    // Test button removed as requested
});
