/**
 * Force Real Email Mode
 * This script forces the email service to use real email mode
 * It overrides any existing configuration
 */

// Execute immediately when loaded
(function() {
    console.log('FORCE REAL EMAIL MODE: Overriding email configuration');
    
    // Create a style for the real email mode notification
    const style = document.createElement('style');
    style.textContent = `
        .real-email-banner {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #28a745;
            color: white;
            text-align: center;
            padding: 10px;
            font-weight: bold;
            z-index: 9999;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
    `;
    document.head.appendChild(style);
    
    // Create and show the real email mode banner
    const banner = document.createElement('div');
    banner.className = 'real-email-banner';
    banner.textContent = 'REAL EMAIL MODE: Emails will be sent to actual recipients';
    document.body.appendChild(banner);
    
    // Remove any existing simulation mode banners
    const blueBanners = document.querySelectorAll('div[style*="background-color: rgb(23, 162, 184)"]');
    blueBanners.forEach(banner => {
        if (banner.textContent && banner.textContent.includes('SIMULATION MODE')) {
            banner.parentNode.removeChild(banner);
        }
    });
    
    // Override EmailService configuration if it exists
    if (typeof EmailService !== 'undefined') {
        // Force real email mode
        EmailService.config.useRealEmails = true;
        EmailService.config.useBackendServer = true;
        
        // Override the showNotification method to prevent simulation mode notifications
        const originalShowNotification = EmailService.showNotification;
        EmailService.showNotification = function(message, type, duration) {
            // Replace simulation mode messages with real email messages
            if (message.includes('SIMULATION MODE')) {
                message = 'REAL EMAIL MODE: Emails will be sent to actual recipients';
                type = 'success';
            }
            return originalShowNotification.call(this, message, type, duration);
        };
        
        console.log('Email service configuration overridden:');
        console.log('- Using real emails:', EmailService.config.useRealEmails);
        console.log('- Using backend server:', EmailService.config.useBackendServer);
    }
})();
