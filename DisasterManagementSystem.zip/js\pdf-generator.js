/**
 * PDF Generator for Disaster Management System
 * This file contains functions to generate PDF documents for disaster precautions
 */

// Function to generate a PDF for a specific disaster type
function generatePrecautionsPDF(disasterType, contentElement) {
    try {
        console.log('Starting PDF generation for', disasterType);
        
        // Create a new PDF document
        const doc = new jspdf.jsPDF();
        
        // Add title
        doc.setFontSize(22);
        doc.setTextColor(41, 128, 185);
        const title = capitalizeFirstLetter(disasterType) + ' Safety Protocols';
        doc.text(title, doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });
        
        // Add subtitle
        doc.setFontSize(12);
        doc.setTextColor(100, 100, 100);
        doc.text('Disaster Management System - Safety Precautions', doc.internal.pageSize.getWidth() / 2, 30, { align: 'center' });
        
        // Add date
        const today = new Date();
        doc.setFontSize(10);
        doc.text('Generated on: ' + today.toLocaleDateString(), doc.internal.pageSize.getWidth() / 2, 38, { align: 'center' });
        
        // Add horizontal line
        doc.setDrawColor(200, 200, 200);
        doc.line(20, 42, doc.internal.pageSize.getWidth() - 20, 42);
        
        // Extract content
        const cardTitle = contentElement.querySelector('.card-title')?.textContent || title;
        const phases = contentElement.querySelectorAll('.precaution-phases');
        
        // Add card title
        doc.setFontSize(16);
        doc.setTextColor(0, 0, 0);
        doc.text(cardTitle, 20, 50);
        
        let yPosition = 60;
        
        // Add each phase
        phases.forEach(phase => {
            // Add phase title
            const phaseTitle = phase.querySelector('.phase-title')?.textContent || 'Safety Measures';
            doc.setFontSize(14);
            doc.setTextColor(41, 128, 185);
            
            // Check if we need a new page
            if (yPosition > 270) {
                doc.addPage();
                yPosition = 20;
            }
            
            doc.text(phaseTitle, 20, yPosition);
            yPosition += 10;
            
            // Add precautions
            const precautions = phase.querySelectorAll('.precaution-list li');
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            
            precautions.forEach(precaution => {
                // Check if we need a new page
                if (yPosition > 270) {
                    doc.addPage();
                    yPosition = 20;
                }
                
                // Add precaution text with bullet point
                const text = '• ' + precaution.textContent;
                const splitText = doc.splitTextToSize(text, 170);
                doc.text(splitText, 20, yPosition);
                yPosition += 7 * splitText.length;
            });
            
            yPosition += 10; // Add space between phases
        });
        
        // Add footer to all pages
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setTextColor(150, 150, 150);
            doc.text('Page ' + i + ' of ' + pageCount + ' - Disaster Management System', doc.internal.pageSize.getWidth() / 2, doc.internal.pageSize.getHeight() - 10, { align: 'center' });
        }
        
        // Save the PDF
        const filename = disasterType + '_safety_protocols.pdf';
        doc.save(filename);
        console.log('PDF saved as', filename);
        
        return true;
    } catch (error) {
        console.error('Error generating PDF:', error);
        alert('Failed to generate PDF. Please try again.');
        return false;
    }
}

// Function to generate a comprehensive PDF with all disaster types
function generateAllPrecautionsPDF() {
    try {
        console.log('Starting comprehensive PDF generation');
        
        // Create a new PDF document
        const doc = new jspdf.jsPDF();
        
        // Add title
        doc.setFontSize(22);
        doc.setTextColor(41, 128, 185);
        doc.text('Comprehensive Disaster Safety Protocols', doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });
        
        // Add subtitle
        doc.setFontSize(12);
        doc.setTextColor(100, 100, 100);
        doc.text('Disaster Management System - Complete Safety Guide', doc.internal.pageSize.getWidth() / 2, 30, { align: 'center' });
        
        // Add date
        const today = new Date();
        doc.setFontSize(10);
        doc.text('Generated on: ' + today.toLocaleDateString(), doc.internal.pageSize.getWidth() / 2, 38, { align: 'center' });
        
        // Add horizontal line
        doc.setDrawColor(200, 200, 200);
        doc.line(20, 42, doc.internal.pageSize.getWidth() - 20, 42);
        
        // Get all disaster types
        const disasterTabs = document.querySelectorAll('.disaster-tab');
        let yPosition = 50;
        
        // Process each disaster type
        for (let i = 0; i < disasterTabs.length; i++) {
            const disasterType = disasterTabs[i].getAttribute('data-disaster');
            const contentElement = document.getElementById(disasterType + '-precautions');
            
            // Check if we need a new page
            if (i > 0) {
                doc.addPage();
                yPosition = 20;
            }
            
            // Add disaster type title
            doc.setFontSize(18);
            doc.setTextColor(41, 128, 185);
            doc.text(capitalizeFirstLetter(disasterType) + ' Safety Protocols', 20, yPosition);
            yPosition += 10;
            
            // Extract content
            const phases = contentElement.querySelectorAll('.precaution-phases');
            
            // If there are no detailed phases, add placeholder text
            if (phases.length === 0) {
                doc.setFontSize(12);
                doc.setTextColor(0, 0, 0);
                doc.text('Detailed safety information for this disaster type.', 20, yPosition);
                yPosition += 10;
                continue;
            }
            
            // Add each phase
            phases.forEach(phase => {
                // Add phase title
                const phaseTitle = phase.querySelector('.phase-title')?.textContent || 'Safety Measures';
                doc.setFontSize(14);
                doc.setTextColor(41, 128, 185);
                
                // Check if we need a new page
                if (yPosition > 270) {
                    doc.addPage();
                    yPosition = 20;
                }
                
                doc.text(phaseTitle, 20, yPosition);
                yPosition += 8;
                
                // Add precautions
                const precautions = phase.querySelectorAll('.precaution-list li');
                doc.setFontSize(12);
                doc.setTextColor(0, 0, 0);
                
                precautions.forEach(precaution => {
                    // Check if we need a new page
                    if (yPosition > 270) {
                        doc.addPage();
                        yPosition = 20;
                    }
                    
                    // Add precaution text with bullet point
                    const text = '• ' + precaution.textContent;
                    const splitText = doc.splitTextToSize(text, 170);
                    doc.text(splitText, 20, yPosition);
                    yPosition += 6 * splitText.length;
                });
                
                yPosition += 8; // Add space between phases
            });
        }
        
        // Add footer to all pages
        const pageCount = doc.internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setTextColor(150, 150, 150);
            doc.text('Page ' + i + ' of ' + pageCount + ' - Disaster Management System', doc.internal.pageSize.getWidth() / 2, doc.internal.pageSize.getHeight() - 10, { align: 'center' });
        }
        
        // Save the PDF
        doc.save('comprehensive_disaster_safety_protocols.pdf');
        console.log('Comprehensive PDF saved');
        
        return true;
    } catch (error) {
        console.error('Error generating comprehensive PDF:', error);
        alert('Failed to generate comprehensive PDF. Please try again.');
        return false;
    }
}

// Helper function to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}
