/**
 * Dropdown Menu for Disaster Management System
 * This script handles the dropdown menu functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'nav-toggle-btn';
    toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';

    const navContainer = document.querySelector('.nav-container');
    const navbar = document.querySelector('.navbar');

    if (navContainer) {
        navContainer.prepend(toggleBtn);

        toggleBtn.addEventListener('click', function() {
            navbar.classList.toggle('mobile-open');

            // Change icon based on state
            if (navbar.classList.contains('mobile-open')) {
                toggleBtn.innerHTML = '<i class="fas fa-times"></i>';
            } else {
                toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });
    }

    // Click-based dropdown toggle for all screen sizes
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        // Only add click handler to links that have dropdown menus
        const parent = link.parentElement;
        const dropdownMenu = parent.querySelector('.dropdown-menu');

        if (dropdownMenu) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent event bubbling

                // Check if this item is already active
                const isActive = parent.classList.contains('active');

                // Close all dropdowns first
                document.querySelectorAll('.nav-item').forEach(item => {
                    item.classList.remove('active');
                });

                // If it wasn't active before, make it active now
                if (!isActive) {
                    parent.classList.add('active');
                }
            });
        }
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.nav-item') && !e.target.closest('.nav-toggle-btn')) {
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
        }
    });

    // Prevent dropdown menu clicks from closing the dropdown
    document.querySelectorAll('.dropdown-menu').forEach(menu => {
        menu.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent event bubbling
        });
    });

    // Highlight current page
    const currentPage = window.location.pathname.split('/').pop() || 'home.html';

    document.querySelectorAll('.dropdown-item').forEach(item => {
        const href = item.getAttribute('href');
        if (href === currentPage) {
            item.classList.add('active');

            // For mobile view, expand the parent dropdown
            const parent = item.closest('.nav-item');
            if (parent && window.innerWidth <= 768) {
                parent.classList.add('active');
            }
        }
    });

    // Display welcome message with user's name
    const userWelcome = document.getElementById('userWelcome');
    if (userWelcome) {
        const userSession = JSON.parse(localStorage.getItem('currentUserSession'));
        if (userSession && userSession.fullname) {
            userWelcome.textContent = `Welcome, ${userSession.fullname}`;
        }
    }

    // Handle logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();

            // Get user session
            const userSession = JSON.parse(localStorage.getItem('currentUserSession'));

            // Update session status
            if (userSession) {
                // Mark session as inactive
                userSession.active = false;
                localStorage.setItem('currentUserSession', JSON.stringify(userSession));

                // Update active users list
                let activeUsers = JSON.parse(localStorage.getItem('activeUsers') || '[]');
                activeUsers = activeUsers.filter(user => user.userId !== userSession.userId);
                localStorage.setItem('activeUsers', JSON.stringify(activeUsers));
            }

            // Redirect to login page
            window.location.href = 'index.html';
        });
    }
});
