/**
 * Test Email Script
 * This script provides a way to test email sending functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Test Email Script loaded');
    // Test buttons removed as requested
});
