/**
 * Alert Debug Script
 * This script helps diagnose issues with alert creation
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Alert Debug Script loaded');

    // Check if user is logged in
    const userSession = JSON.parse(localStorage.getItem('currentUserSession') || 'null');
    console.log('Current user session:', userSession);

    if (!userSession || !userSession.active) {
        console.error('No active user session found. Login is required to create alerts.');
        alert('Please log in to create alerts. Redirecting to login page...');
        // Uncomment to redirect: window.location.href = 'login.html';
    }

    // Check if localStorage is working
    try {
        // Test localStorage
        localStorage.setItem('testKey', 'testValue');
        const testValue = localStorage.getItem('testKey');
        console.log('localStorage test:', testValue === 'testValue' ? 'PASSED' : 'FAILED');
        localStorage.removeItem('testKey');

        // Check existing alerts
        const registeredAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');
        console.log('Current registered alerts:', registeredAlerts);
        console.log('Number of alerts:', registeredAlerts.length);

        // Test button removed as requested

        // Function to create a test alert directly
        function createTestAlert() {
            console.log('Creating test alert...');

            // Generate a unique ID for the alert
            const alertId = 'TEST-' + Date.now().toString().slice(-6);
            const currentDate = new Date().toISOString().split('T')[0];
            const timestamp = new Date().toISOString();

            // Create alert object
            const testAlert = {
                id: alertId,
                disasterType: 'Test Alert',
                date: currentDate,
                location: 'Test Location',
                severity: 'Low',
                affectedAreas: 'Test Area',
                status: 'Test',
                description: 'This is a test alert created for debugging purposes.',
                reportedBy: 'Debug Script',
                timestamp: timestamp,
                evacuationOrders: 'None - this is a test',
                emergencyContacts: 'N/A - this is a test'
            };

            console.log('Test alert object:', testAlert);

            // Method 1: Direct localStorage update
            try {
                let existingAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');
                existingAlerts.push(testAlert);
                localStorage.setItem('registeredAlerts', JSON.stringify(existingAlerts));
                console.log('Method 1 (Direct): Alert saved successfully');
                console.log('Updated alerts count:', existingAlerts.length);
            } catch (error) {
                console.error('Method 1 (Direct) Error:', error);
            }

            // Method 2: Using StorageUtils
            try {
                if (typeof StorageUtils !== 'undefined') {
                    const success = StorageUtils.addToArray('registeredAlerts', testAlert);
                    console.log('Method 2 (StorageUtils): Alert saved successfully:', success);

                    const updatedAlerts = StorageUtils.loadData('registeredAlerts', []);
                    console.log('Updated alerts count (StorageUtils):', updatedAlerts.length);
                } else {
                    console.error('StorageUtils is not defined');
                }
            } catch (error) {
                console.error('Method 2 (StorageUtils) Error:', error);
            }

            // Verify the alert was saved
            const savedAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');
            console.log('Final alerts count:', savedAlerts.length);
            console.log('Test alert saved:', savedAlerts.some(alert => alert.id === alertId));

            // Show success message
            alert(`Test alert ${alertId} has been created. Check the registered alerts page to verify.`);
        }

    } catch (error) {
        console.error('localStorage error:', error);
        alert('Error accessing localStorage. This may be causing issues with alert creation.');
    }
});
