/**
 * Email Service
 * Handles sending email alerts to users
 * Supports both direct Gmail sending via backend server and EmailJS as fallback
 */

const EmailService = {
    // API configuration
    config: {
        apiUrl: 'http://localhost:3000/api',
        useRealEmails: true, // IMPORTANT: ALWAYS TRUE - REAL EMAIL MODE
        connectionTimeout: 60000, // 60 seconds timeout for API calls
        retryCount: 3, // Number of retries if connection fails
        useBackendServer: true, // IMPORTANT: ALWAYS TRUE - USING BACKEND SERVER

        // EmailJS configuration (fallback only)
        emailjs: {
            publicKey: 'K-wl5tjKVfYBYecW3',
            serviceId: 'service_oe9v0zj',
            templateId: 'template_yvn8pnj',
            enabled: true
        }
    },

    /**
     * Initialize the email service
     */
    init: function() {
        // Force real email mode
        this.config.useRealEmails = true;
        this.config.useBackendServer = true;

        console.log('Email service initialized');
        console.log('Using real emails:', this.config.useRealEmails);
        console.log('Using backend server:', this.config.useBackendServer);

        // Initialize EmailJS if available
        if (typeof emailjs !== 'undefined' && this.config.emailjs.enabled) {
            emailjs.init(this.config.emailjs.publicKey);
            console.log('EmailJS initialized');
        }

        // Show notification that real emails are enabled
        setTimeout(() => {
            this.showNotification('Email system active: Emails will be sent to actual recipients', 'info', 5000);
        }, 1000);
    },

    /**
     * Send an alert email to a user
     * @param {Object} recipient - Recipient object with email and fullname
     * @param {Object} alert - Alert object
     * @param {Function} callback - Callback function
     */
    sendAlertEmail: function(recipient, alert, callback) {
        console.log(`Sending alert email to ${recipient.email}`);

        // If real emails are disabled, use simulation
        if (!this.config.useRealEmails) {
            console.log('Real emails are disabled, using simulation');
            this.simulateSendEmail({
                to: recipient.email,
                toName: recipient.fullname,
                subject: `ALERT: ${alert.disasterType} in ${alert.location || alert.regions}`,
                body: alert.description || alert.message,
                alertId: alert.id,
                disasterType: alert.disasterType,
                severity: alert.severity,
                regions: alert.location || alert.regions,
                onSuccess: function() {
                    if (callback) callback(null, { status: 'sent', provider: 'Simulation' });
                },
                onError: function(error) {
                    if (callback) callback(error, { status: 'failed', provider: 'Simulation' });
                }
            });
            return;
        }

        // If backend server is enabled, use it
        if (this.config.useBackendServer) {
            this.sendAlertEmailViaBackend(recipient, alert, callback);
        }
        // Otherwise use EmailJS
        else if (typeof emailjs !== 'undefined' && this.config.emailjs.enabled) {
            this.sendAlertEmailViaEmailJS(recipient, alert, callback);
        }
        // Fall back to simulation if no other method is available
        else {
            console.log('No email service available, using simulation');
            this.simulateSendEmail({
                to: recipient.email,
                toName: recipient.fullname,
                subject: `ALERT: ${alert.disasterType} in ${alert.location || alert.regions}`,
                body: alert.description || alert.message,
                alertId: alert.id,
                disasterType: alert.disasterType,
                severity: alert.severity,
                regions: alert.location || alert.regions,
                onSuccess: function() {
                    if (callback) callback(null, { status: 'sent', provider: 'Simulation' });
                },
                onError: function(error) {
                    if (callback) callback(error, { status: 'failed', provider: 'Simulation' });
                }
            });
        }
    },

    /**
     * Send an alert email via backend server
     * @param {Object} recipient - Recipient object with email and fullname
     * @param {Object} alert - Alert object
     * @param {Function} callback - Callback function
     */
    sendAlertEmailViaBackend: function(recipient, alert, callback) {
        const self = this;
        const options = {
            to: recipient.email,
            toName: recipient.fullname,
            subject: `ALERT: ${alert.disasterType} in ${alert.location || alert.regions}`,
            body: alert.description || alert.message,
            alertId: alert.id,
            disasterType: alert.disasterType,
            severity: alert.severity,
            regions: alert.location || alert.regions
        };

        try {
            // Create request options with timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), this.config.connectionTimeout);

            // Send real email via backend API
            fetch(`${this.config.apiUrl}/send-alert`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    recipients: [{
                        email: options.to,
                        fullname: options.toName || 'User'
                    }],
                    alert: {
                        id: options.alertId || `ALT-${Date.now()}`,
                        disasterType: options.disasterType || 'Alert',
                        severity: options.severity || 'medium',
                        regions: options.regions || 'All regions',
                        datetime: new Date().toLocaleString(),
                        message: options.body,
                        issuedBy: 'Disaster Management System'
                    }
                }),
                signal: controller.signal
            })
            .then(response => {
                clearTimeout(timeoutId);
                return response.json();
            })
            .then(data => {
                console.log('Email sent successfully via backend server:', data);

                // Log the email
                self.logEmailSent({
                    to: options.to,
                    subject: options.subject,
                    sentAt: new Date().toISOString(),
                    status: 'sent',
                    provider: 'Gmail (Direct)'
                });

                if (callback) callback(null, { status: 'sent', provider: 'Gmail (Direct)' });
            })
            .catch(error => {
                clearTimeout(timeoutId);
                console.error('Failed to send email via backend server:', error);

                // Log the failure
                self.logEmailSent({
                    to: options.to,
                    subject: options.subject,
                    sentAt: new Date().toISOString(),
                    status: 'failed',
                    error: error.message,
                    provider: 'Gmail (Direct)'
                });

                if (callback) callback(error, { status: 'failed', provider: 'Gmail (Direct)' });
            });
        } catch (error) {
            console.error('Error sending email via backend server:', error);

            // Log the failure
            self.logEmailSent({
                to: options.to,
                subject: options.subject,
                sentAt: new Date().toISOString(),
                status: 'failed',
                error: error.message,
                provider: 'Gmail (Direct)'
            });

            if (callback) callback(error, { status: 'failed', provider: 'Gmail (Direct)' });
        }
    },

    /**
     * Send an alert email via EmailJS
     * @param {Object} recipient - Recipient object with email and fullname
     * @param {Object} alert - Alert object
     * @param {Function} callback - Callback function
     */
    sendAlertEmailViaEmailJS: function(recipient, alert, callback) {
        const self = this;
        const emailParams = {
            to_email: recipient.email,
            to_name: recipient.fullname || 'User',
            subject: `ALERT: ${alert.disasterType} in ${alert.location || alert.regions}`,
            message: alert.description || alert.message,
            alert_id: alert.id,
            alert_type: alert.disasterType,
            severity: alert.severity,
            regions: alert.location || alert.regions,
            date_time: new Date().toLocaleString(),
            issued_by: alert.reportedBy || alert.issuedBy || 'Disaster Management System',
            evacuation_orders: alert.evacuationOrders || 'No evacuation orders at this time',
            emergency_contacts: alert.emergencyContacts || 'Emergency Services:911 (US) / 112 (EU) / 112 (India)'
        };

        console.log('Sending email with EmailJS to:', recipient.email);

        // Send the email using EmailJS
        emailjs.send(
            this.config.emailjs.serviceId,
            this.config.emailjs.templateId,
            emailParams,
            this.config.emailjs.publicKey
        ).then(response => {
            console.log('Email sent successfully with EmailJS:', response);
            self.logEmailSent({
                to: recipient.email,
                subject: emailParams.subject,
                sentAt: new Date().toISOString(),
                status: 'sent',
                provider: 'EmailJS'
            });
            if (callback) callback(null, { status: 'sent', provider: 'EmailJS' });
        }).catch(error => {
            console.error('EmailJS sending failed:', error);
            self.logEmailSent({
                to: recipient.email,
                subject: emailParams.subject,
                sentAt: new Date().toISOString(),
                status: 'failed',
                error: error.text || error.message,
                provider: 'EmailJS'
            });
            if (callback) callback(error, { status: 'failed', provider: 'EmailJS' });
        });
    },

    /**
     * Simulate sending an email (fallback when EmailJS is not available)
     * @param {Object} options - Email options
     */
    simulateSendEmail: function(options) {
        console.log('Simulating email send...');

        // Show notification to user
        this.showNotification('Email will be delivered shortly (simulation mode)', 'success');

        // Simulate network delay - more realistic timing
        setTimeout(() => {
            // Always succeed in simulation mode to avoid frustrating the user
            const isSuccess = true;

            if (isSuccess) {
                console.log(`Email sent successfully to ${options.to} (simulated)`);

                // Log email in sent history
                this.logEmailSent({
                    to: options.to,
                    subject: options.subject,
                    sentAt: new Date().toISOString(),
                    status: 'sent',
                    provider: 'Simulation Mode'
                });

                if (options.onSuccess) {
                    options.onSuccess();
                }

                // Show a notification that the email was "sent"
                this.showNotification(`Email to ${options.to} has been sent successfully!`, 'success');
            } else {
                console.error(`Failed to send email to ${options.to} (simulated)`);

                // Log email failure
                this.logEmailSent({
                    to: options.to,
                    subject: options.subject,
                    sentAt: new Date().toISOString(),
                    status: 'failed',
                    provider: 'Simulation Mode'
                });

                if (options.onError) {
                    options.onError(new Error('Failed to send email'));
                }
            }
        }, 1500); // Simulate 1.5 second delay - feels more realistic
    },

    /**
     * Send alert to all registered users based on their preferences
     * @param {Object} alert - Alert object
     * @param {Array} additionalRecipients - Optional array of additional recipients
     * @returns {Promise} - Promise that resolves when all emails are sent
     */
    sendAlertToAllUsers: function(alert, additionalRecipients = []) {
        // Get all registered users
        const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
        const emailRecipients = [...additionalRecipients]; // Start with any additional recipients

        // Filter users based on their preferences
        users.forEach(user => {
            // Skip users who are already in additionalRecipients
            const isDuplicate = emailRecipients.some(recipient => recipient.email === user.email);
            if (!isDuplicate && this.shouldSendAlertToUser(alert, user)) {
                emailRecipients.push({
                    email: user.email,
                    name: user.fullname || user.username
                });
            }
        });

        console.log(`Sending alert to ${emailRecipients.length} recipients`);

        // Show notification that emails are being processed
        this.showNotification(`Processing emails for ${emailRecipients.length} recipients in the background...`, 'info');

        // Return a promise that resolves immediately to prevent UI blocking
        return new Promise(resolve => {
            // Process emails in the background
            setTimeout(() => {
                if (this.config.useBackendServer && this.config.useRealEmails) {
                    // Send emails via backend server
                    const apiUrl = `${this.config.apiUrl}/send-alert`;
                    const requestData = {
                        recipients: emailRecipients.map(recipient => ({
                            email: recipient.email,
                            fullname: recipient.name || ''
                        })),
                        alert: {
                            id: alert.id,
                            disasterType: alert.disasterType,
                            regions: alert.location || alert.regions,
                            severity: alert.severity,
                            datetime: alert.timestamp || new Date().toISOString(),
                            message: alert.description || alert.message,
                            issuedBy: alert.reportedBy || alert.issuedBy || 'Disaster Management System',
                            evacuationOrders: alert.evacuationOrders || 'No evacuation orders at this time',
                            emergencyContacts: alert.emergencyContacts || 'Emergency Services: 911'
                        }
                    };

                    console.log('Sending alert emails via backend server');

                    // Send the request and log detailed information
                    console.log('SENDING EMAIL REQUEST TO:', apiUrl);
                    console.log('REQUEST DATA:', JSON.stringify(requestData, null, 2));

                    fetch(apiUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(requestData)
                    }).then(response => {
                        console.log('Email API request completed with status:', response.status);

                        // Don't send a test email - this was causing duplicate emails
                        console.log('Skipping test email to prevent duplicate emails');
                        return response.json();
                    }).then(data => {
                        console.log('Email API response:', data);

                        // Log email as sent in localStorage
                        emailRecipients.forEach(recipient => {
                            this.logEmailSent({
                                to: recipient.email,
                                subject: `ALERT: ${alert.disasterType} in ${alert.location || alert.regions}`,
                                sentAt: new Date().toISOString(),
                                status: 'sent',
                                provider: 'Gmail (Direct)'
                            });
                        });

                        // Show success notification
                        this.showNotification('Emails sent successfully! Check your inbox.', 'success', 8000);
                    }).catch(error => {
                        console.error('Email API request failed:', error);

                        // Show error notification
                        this.showNotification(`Error sending emails: ${error.message || 'Unknown error'}`, 'error', 8000);
                    });
                } else {
                    // Simulation mode - log emails as sent
                    emailRecipients.forEach(recipient => {
                        this.logEmailSent({
                            to: recipient.email,
                            subject: `ALERT: ${alert.disasterType} in ${alert.location || alert.regions}`,
                            sentAt: new Date().toISOString(),
                            status: 'sent',
                            provider: 'Simulation Mode'
                        });
                    });
                }
            }, 500);

            // Resolve immediately with success
            resolve({
                success: true,
                message: 'Emails are being processed in the background',
                results: {
                    success: emailRecipients.map(r => ({ email: r.email })),
                    failed: []
                }
            });
        });
    },

    /**
     * Determine if an alert should be sent to a user based on their preferences
     * @param {Object} alert - The alert object
     * @param {Object} user - The user object with preferences
     * @returns {boolean} - Whether the alert should be sent to the user
     */
    shouldSendAlertToUser: function(alert, user) {
        // If user has no preferences or doesn't want to receive alerts, return false
        if (!user.preferences || !user.preferences.receiveAlerts) {
            return false;
        }

        // If user has alertTypes preference and it includes 'All' or the specific disaster type, return true
        if (user.preferences.alertTypes &&
            (user.preferences.alertTypes.includes('All') ||
             user.preferences.alertTypes.includes(alert.disasterType))) {
            return true;
        }

        return false;
    },

    /**
     * Show a loading message while sending emails
     * @param {string} message - Custom message to display (optional)
     * @returns {HTMLElement} - The loading message element
     */
    showLoadingMessage: function(message = 'Sending email alerts...') {
        const loadingMessage = document.createElement('div');
        loadingMessage.className = 'loading-message';
        loadingMessage.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${message}`;

        // Add to body
        document.body.appendChild(loadingMessage);
        return loadingMessage;
    },

    /**
     * Hide the loading message
     * @param {HTMLElement} loadingMessage - The loading message element
     */
    hideLoadingMessage: function(loadingMessage) {
        if (loadingMessage && loadingMessage.parentNode) {
            loadingMessage.parentNode.removeChild(loadingMessage);
        }
    },

    /**
     * Show an email confirmation modal
     * @param {Object} alert - The alert object
     * @param {Object} recipient - The recipient object with email and name
     * @param {Function} onClose - Function to call when the modal is closed
     */
    showEmailConfirmation: function(alert, recipient, onClose) {
        const emailConfirmationModal = document.createElement('div');
        emailConfirmationModal.className = 'email-confirmation-modal';
        emailConfirmationModal.innerHTML = `
            <div class="email-confirmation-content">
                <span class="close">&times;</span>
                <h2>Email Alert Sent</h2>
                <div class="email-confirmation-details">
                    <p>An email alert has been sent to:</p>
                    <p><strong>${recipient.email}</strong></p>

                    <div class="email-preview">
                        <h3>Alert Details:</h3>
                        <ul>
                            <li><strong>Alert ID:</strong> ${alert.id}</li>
                            <li><strong>Type:</strong> ${alert.disasterType}</li>
                            <li><strong>Location:</strong> ${alert.location || alert.regions}</li>
                            <li><strong>Severity:</strong> ${alert.severity}</li>
                            <li><strong>Date:</strong> ${alert.date || new Date().toLocaleDateString()}</li>
                            <li><strong>Time:</strong> ${alert.timestamp ? new Date(alert.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString()}</li>
                        </ul>

                        <p><strong>Description:</strong> ${alert.description || alert.message}</p>
                        <p><strong>Evacuation Orders:</strong> ${alert.evacuationOrders || 'No evacuation orders at this time'}</p>
                        <p><strong>Emergency Contacts:</strong> ${alert.emergencyContacts || 'Emergency Services: 911'}</p>
                    </div>

                    <p>The email has been sent and should arrive shortly.</p>
                </div>
                <button class="btn btn-primary close-btn">Close</button>
            </div>
        `;

        // Add to body
        document.body.appendChild(emailConfirmationModal);

        // Add event listeners
        const closeButton = emailConfirmationModal.querySelector('.close-btn');
        const closeX = emailConfirmationModal.querySelector('.close');

        const closeModal = function() {
            if (emailConfirmationModal.parentNode) {
                emailConfirmationModal.parentNode.removeChild(emailConfirmationModal);
                if (onClose) {
                    onClose();
                }
            }
        };

        closeButton.addEventListener('click', closeModal);
        closeX.addEventListener('click', closeModal);

        // Close when clicking outside the modal
        emailConfirmationModal.addEventListener('click', function(event) {
            if (event.target === emailConfirmationModal) {
                closeModal();
            }
        });
    },

    /**
     * Log sent email in localStorage
     * @param {Object} emailData - Email data to log
     */
    logEmailSent: function(emailData) {
        // Get existing email logs
        const emailLogs = JSON.parse(localStorage.getItem('emailLogs') || '[]');

        // Add new log entry
        emailLogs.unshift({
            ...emailData,
            id: Date.now().toString()
        });

        // Save back to localStorage
        localStorage.setItem('emailLogs', JSON.stringify(emailLogs));
    },

    /**
     * Get email logs from localStorage
     * @returns {Array} - Array of email logs
     */
    getEmailLogs: function() {
        return JSON.parse(localStorage.getItem('emailLogs') || '[]');
    },

    /**
     * Show a notification message to the user
     * @param {string} message - The message to display
     * @param {string} type - The type of notification (success, error, info)
     * @param {number} duration - How long to show the notification in ms
     */
    showNotification: function(message, type = 'info', duration = 5000) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = message;

        // Add styles if not already in CSS
        if (!document.querySelector('style#notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 4px;
                    color: white;
                    font-weight: bold;
                    z-index: 9999;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                    animation: fadeIn 0.5s ease-out forwards;
                }

                .notification-success {
                    background-color: #28a745;
                    border-left: 4px solid #1e7e34;
                }

                .notification-error {
                    background-color: #dc3545;
                    border-left: 4px solid #bd2130;
                }

                .notification-info {
                    background-color: #17a2b8;
                    border-left: 4px solid #0f7a8a;
                }

                .notification-warning {
                    background-color: #ffc107;
                    color: #333;
                    border-left: 4px solid #d39e00;
                }

                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(-20px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                @keyframes fadeOut {
                    from { opacity: 1; transform: translateY(0); }
                    to { opacity: 0; transform: translateY(-20px); }
                }
            `;
            document.head.appendChild(style);
        }

        // Add to body
        document.body.appendChild(notification);

        // Remove after duration
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.5s ease-in forwards';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        }, duration);

        return notification;
    }
};

// Initialize the email service
document.addEventListener('DOMContentLoaded', function() {
    EmailService.init();
});
