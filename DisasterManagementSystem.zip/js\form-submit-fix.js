/**
 * Form Submit Fix
 * This script adds a direct click handler to the submit button
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Form Submit Fix loaded');

    // Wait for the DOM to be fully loaded
    setTimeout(function() {
        // Get the create alert button
        const submitButton = document.getElementById('createAlertBtn');

        if (submitButton) {
            console.log('Submit button found, adding direct click handler');

            // Add direct click handler
            submitButton.addEventListener('click', function(e) {
                console.log('Submit button clicked directly');
                e.preventDefault();

                // Get form values
                const disasterType = document.getElementById('disasterType').value;
                const location = document.getElementById('location').value;
                const affectedAreasSelect = document.getElementById('affectedAreas');
                const affectedAreas = affectedAreasSelect.options ?
                    Array.from(affectedAreasSelect.options)
                        .filter(option => option.selected)
                        .map(option => option.value)
                        .join(', ') :
                    location;

                const severity = document.getElementById('severity').value;
                const status = document.getElementById('status').value;
                const description = document.getElementById('description').value;
                const evacuationOrders = document.getElementById('evacuationOrders').value || 'No evacuation orders at this time';
                const emergencyContacts = document.getElementById('emergencyContacts').value || 'Local emergency services';

                // Validate required fields
                if (!disasterType || !location || !severity || !status || !description) {
                    alert('Please fill in all required fields (marked with *)');
                    return;
                }

                // Generate a unique ID for the alert
                const alertId = 'ALT' + Date.now().toString().slice(-6);
                const currentDate = new Date().toISOString().split('T')[0];
                const timestamp = new Date().toISOString();

                // Get current user info
                const session = JSON.parse(localStorage.getItem('currentUserSession') || 'null');
                console.log('Current user session:', session);

                const reportedBy = session && session.user ? (session.user.fullname || session.user.username) :
                                  (session && session.fullname ? session.fullname :
                                  (session && session.username ? session.username : 'System Admin'));

                // Create alert object
                const newAlert = {
                    id: alertId,
                    disasterType: disasterType,
                    date: currentDate,
                    location: location,
                    severity: severity,
                    affectedAreas: affectedAreas,
                    status: status,
                    description: description,
                    reportedBy: reportedBy,
                    timestamp: timestamp,
                    evacuationOrders: evacuationOrders,
                    emergencyContacts: emergencyContacts
                };

                console.log('New alert object:', newAlert);

                // Save directly to localStorage
                try {
                    // Get existing alerts
                    let existingAlerts = JSON.parse(localStorage.getItem('registeredAlerts') || '[]');

                    // Add new alert
                    existingAlerts.push(newAlert);

                    // Save back to localStorage
                    localStorage.setItem('registeredAlerts', JSON.stringify(existingAlerts));

                    console.log('Alert saved directly to localStorage');
                    console.log('Total alerts:', existingAlerts.length);

                    // Show success message
                    alert(`Alert ${alertId} has been created successfully!`);

                    // Redirect to registered alerts page
                    window.location.href = 'registered-alerts.html';
                } catch (error) {
                    console.error('Error saving alert directly:', error);
                    alert('Error creating alert: ' + error.message);
                }
            });
        } else {
            console.error('Submit button not found');
        }
    }, 1000); // Wait 1 second for the DOM to be fully loaded
});
