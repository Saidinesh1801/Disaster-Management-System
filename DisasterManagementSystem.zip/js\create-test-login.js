/**
 * Create Test Login Script
 * This script creates a test user and logs them in automatically
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Create Test Login Script loaded');
    
    // Check if user is already logged in
    const userSession = JSON.parse(localStorage.getItem('currentUserSession') || 'null');
    
    if (!userSession || !userSession.active) {
        console.log('No active user session found. Creating test user and logging in...');
        
        // Create a test user if none exists
        const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
        let testUser;
        
        // Check if test user already exists
        const existingTestUser = users.find(user => user.username === 'testuser');
        
        if (existingTestUser) {
            console.log('Test user already exists, using existing user');
            testUser = existingTestUser;
        } else {
            // Create a new test user
            testUser = {
                id: "user-" + Date.now(),
                fullname: "Test User",
                username: "testuser",
                email: "testuser@example.com",
                password: "password",
                dateRegistered: new Date().toISOString(),
                preferences: {
                    receiveAlerts: true,
                    alertTypes: ["All"]
                }
            };
            
            // Add to users array
            users.push(testUser);
            
            // Save to localStorage
            localStorage.setItem('registeredUsers', JSON.stringify(users));
            console.log('Test user created:', testUser);
        }
        
        // Create session object
        const session = {
            userId: testUser.id,
            user: testUser,
            username: testUser.username,
            email: testUser.email,
            fullname: testUser.fullname,
            loginTime: new Date().toISOString(),
            active: true
        };
        
        // Save to localStorage
        localStorage.setItem('currentUserSession', JSON.stringify(session));
        
        // Add to active users list
        let activeUsers = JSON.parse(localStorage.getItem('activeUsers') || '[]');
        
        // Remove any existing session for this user
        activeUsers = activeUsers.filter(activeUser => activeUser.userId !== testUser.id);
        
        // Add new session
        activeUsers.push(session);
        
        // Save back to localStorage
        localStorage.setItem('activeUsers', JSON.stringify(activeUsers));
        
        console.log('Test user logged in successfully');
        
        // Show notification
        const notification = document.createElement('div');
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.padding = '15px 20px';
        notification.style.borderRadius = '4px';
        notification.style.color = 'white';
        notification.style.fontWeight = 'bold';
        notification.style.zIndex = '9999';
        notification.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
        notification.style.backgroundColor = '#28a745';
        notification.textContent = 'Test user logged in automatically: testuser@example.com';
        
        document.body.appendChild(notification);
        
        // Remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
    } else {
        console.log('User already logged in:', userSession);
    }
});
