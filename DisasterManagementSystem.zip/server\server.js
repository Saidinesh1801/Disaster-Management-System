// Load environment variables
require('dotenv').config();

// Import required packages
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

// Debug mode
const DEBUG = process.env.DEBUG_MODE === 'true';

// Create Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Configure CORS
const allowedOrigins = process.env.ALLOWED_ORIGINS.split(',');
app.use(cors({
  origin: function(origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) {
      if (DEBUG) console.log('Request with no origin accepted');
      return callback(null, true);
    }

    if (DEBUG) console.log(`Request from origin: ${origin}`);

    if (allowedOrigins.indexOf(origin) === -1) {
      const msg = 'The CORS policy for this site does not allow access from the specified Origin.';
      console.error(`CORS error: ${msg} for origin ${origin}`);
      return callback(new Error(msg), false);
    }
    return callback(null, true);
  },
  credentials: true,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Parse JSON request body
app.use(bodyParser.json());

// Log all requests
app.use((req, res, next) => {
  if (DEBUG) {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    if (req.body && Object.keys(req.body).length > 0) {
      console.log('Request body:', JSON.stringify(req.body, null, 2));
    }
  }
  next();
});

// Create email transporter
let transporter;

try {
  // For Gmail
  if (process.env.EMAIL_SERVICE.toLowerCase() === 'gmail') {
    transporter = nodemailer.createTransport({
      service: 'gmail',
      host: 'smtp.gmail.com',
      port: 465,
      secure: true, // use SSL
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      },
      tls: {
        rejectUnauthorized: false // Less strict about certificates
      },
      // Enhanced connection pool settings
      pool: true,
      maxConnections: 5,
      maxMessages: 200, // Increased from 100
      // Improved timeout settings
      connectionTimeout: 60000, // 60 seconds
      socketTimeout: 120000, // 120 seconds
      // Gmail-specific settings to optimize throughput
      rateDelta: 1000, // Minimum milliseconds between messages
      rateLimit: 30 // Maximum number of messages per second
    });
  }
  // For other services or SMTP
  else {
    transporter = nodemailer.createTransport({
      service: process.env.EMAIL_SERVICE,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      },
      // Add connection pool settings
      pool: true,
      maxConnections: 5,
      maxMessages: 100,
      // Add timeout settings
      connectionTimeout: 30000, // 30 seconds
      socketTimeout: 60000 // 60 seconds
    });
  }

  console.log(`Email transporter created for service: ${process.env.EMAIL_SERVICE}`);
  console.log(`Using email account: ${process.env.EMAIL_USER}`);
  console.log('Email connection pool enabled with improved timeout settings');
} catch (error) {
  console.error('Failed to create email transporter:', error);
}

// Verify email configuration with enhanced error reporting
transporter.verify(function(error, success) {
  if (error) {
    console.error('⚠️ EMAIL CONFIGURATION ERROR ⚠️');
    console.error('Detailed error:', error);

    // Log specific error information based on error type
    if (error.code === 'EAUTH') {
      console.error('Authentication error: The provided credentials were rejected by the Gmail server.');
    } else if (error.code === 'ESOCKET') {
      console.error('Socket error: Could not establish a connection to the Gmail server.');
    } else if (error.code === 'ETIMEDOUT') {
      console.error('Timeout error: The connection to the Gmail server timed out.');
    }

    console.log('\n🔧 POSSIBLE SOLUTIONS:');
    console.log('1. Check if your email and password are correct');
    console.log('2. For Gmail, you MUST use an App Password, not your regular password');
    console.log('   - Go to https://myaccount.google.com/apppasswords to generate one');
    console.log('3. Make sure 2-Step Verification is enabled for your Google account');
    console.log('4. Check if your Gmail account has any security restrictions');
    console.log('5. Try using a different Gmail account for testing');

    // Create a test email function to verify credentials
    console.log('\n🧪 TESTING EMAIL CREDENTIALS...');
    testEmailCredentials();
  } else {
    console.log('✅ Email server is ready to send messages');
    console.log('📧 Using email account:', process.env.EMAIL_USER);
    console.log('🔄 Email connection pool enabled with improved timeout settings');
  }
});

// Function to test email credentials
async function testEmailCredentials() {
  try {
    // Create a test transporter with basic settings
    const testTransporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    // Try to verify the connection
    const testResult = await testTransporter.verify();
    console.log('✅ Test connection successful! Your credentials are valid.');
  } catch (testError) {
    console.error('❌ Test connection failed:', testError.message);
    console.log('Please check your EMAIL_USER and EMAIL_PASS in the .env file.');
  }
}

// API endpoint to send alert emails
app.post('/api/send-alert', async (req, res) => {
  try {
    const { recipients, alert } = req.body;

    if (DEBUG) {
      console.log('Received alert email request:');
      console.log('- Recipients:', JSON.stringify(recipients));
      console.log('- Alert:', JSON.stringify(alert));
    }

    if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
      return res.status(400).json({ success: false, message: 'Recipients list is required' });
    }

    if (!alert) {
      return res.status(400).json({ success: false, message: 'Alert data is required' });
    }

    console.log(`Sending alert emails to ${recipients.length} recipients`);

    // Respond immediately to client
    res.json({
      success: true,
      message: `Processing ${recipients.length} emails in the background`,
      alertId: alert.id
    });

    // Track successful and failed emails
    const results = {
      success: [],
      failed: []
    };

    // Process emails in the background with rate limiting
    (async () => {
      // Reduce delays for immediate email delivery
      const BATCH_SIZE = 30; // Send 30 emails at a time
      const DELAY_BETWEEN_BATCHES = 5000; // 5 seconds between batches (reduced from 1 hour)
      const DELAY_BETWEEN_EMAILS = 500; // 0.5 seconds between individual emails (reduced from 2s)

      console.log('IMPORTANT: Using reduced delays for immediate email delivery');

      // Split recipients into batches
      const batches = [];
      for (let i = 0; i < recipients.length; i += BATCH_SIZE) {
        batches.push(recipients.slice(i, i + BATCH_SIZE));
      }

      console.log(`Split ${recipients.length} recipients into ${batches.length} batches of max ${BATCH_SIZE} emails`);

      // Process each batch with delay between batches
      for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        const batch = batches[batchIndex];
        console.log(`Processing batch ${batchIndex + 1} of ${batches.length} with ${batch.length} recipients`);

        // If not the first batch, wait before processing
        if (batchIndex > 0) {
          console.log(`Waiting ${DELAY_BETWEEN_BATCHES/1000/60} minutes before processing next batch to avoid Gmail rate limits...`);
          await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_BATCHES));
          console.log('Resuming email sending for next batch');
        }

        // Process each recipient in the batch with a small delay between emails
        for (const recipient of batch) {
          try {
            if (!recipient.email) {
              console.error('Recipient missing email address');
              results.failed.push({
                email: 'unknown',
                error: 'Missing email address'
              });
              continue;
            }

            console.log(`Preparing to send email to ${recipient.email}`);

            // Add a small delay between individual emails
            if (batch.indexOf(recipient) > 0) {
              await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_EMAILS));
            }

        // Create email content based on alert severity
        const subjectPrefix = alert.severity === 'critical' ? '🚨 URGENT: ' :
                             alert.severity === 'high' ? '⚠️ IMPORTANT: ' : '';

        const subject = `${subjectPrefix}${alert.disasterType} Alert for ${alert.regions}`;

        // Create HTML email content
        const htmlContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: ${getSeverityColor(alert.severity)}; color: white; padding: 15px; text-align: center;">
              <h1>${alert.disasterType} Alert</h1>
              <p style="font-size: 18px;">Severity: ${alert.severity.toUpperCase()}</p>
            </div>

            <div style="padding: 20px; border: 1px solid #ddd; background-color: #f9f9f9;">
              <p>Dear ${recipient.fullname || 'User'},</p>

              <p>A ${alert.severity} ${alert.disasterType} alert has been issued for the following regions:</p>
              <p style="font-weight: bold;">${alert.regions}</p>

              <p>${alert.message}</p>

              <div style="margin: 25px 0; padding: 15px; background-color: #f0f0f0; border-left: 4px solid #999;">
                <p><strong>Alert Details:</strong></p>
                <ul>
                  <li>Alert ID: ${alert.id}</li>
                  <li>Date & Time: ${alert.datetime}</li>
                  <li>Issued By: ${alert.issuedBy || 'Disaster Management System'}</li>
                </ul>
              </div>

              <div style="margin: 25px 0; padding: 15px; background-color: #f5f5f5; border-left: 4px solid #e74c3c;">
                <p><strong>Evacuation Orders:</strong></p>
                <p>${alert.evacuationOrders || 'No evacuation orders at this time'}</p>
              </div>

              <div style="margin: 25px 0; padding: 15px; background-color: #f5f5f5; border-left: 4px solid #3498db;">
                <p><strong>Emergency Contacts:</strong></p>
                <p>${alert.emergencyContacts || 'Emergency Services: 911'}</p>
              </div>

              <p>Please take necessary precautions and stay safe.</p>

              <p>Regards,<br>Disaster Management System</p>
            </div>

            <div style="padding: 10px; background-color: #f0f0f0; font-size: 12px; text-align: center;">
              <p>This is an automated alert from the Disaster Management System.</p>
              <p>To update your notification preferences, please log in to your account.</p>
            </div>
          </div>
        `;

        // Email options
        const mailOptions = {
          from: process.env.EMAIL_FROM,
          to: recipient.email,
          subject: subject,
          html: htmlContent
        };

        if (DEBUG) {
          console.log('Sending email with options:', JSON.stringify({
            to: mailOptions.to,
            subject: mailOptions.subject,
            from: mailOptions.from
          }));
        }

        // Send email with improved error handling
        try {
          console.log(`Attempting to send email to ${recipient.email} with subject: ${mailOptions.subject}`);

          // Send the email directly
          const info = await transporter.sendMail(mailOptions);

          console.log(`Email sent successfully to ${recipient.email}`);
          console.log(`Message ID: ${info.messageId}`);
          console.log(`Response: ${info.response || 'No response'}`);

          // Log success
          console.log(`Email sent to ${recipient.email}: ${info.messageId}`);
          results.success.push({
            email: recipient.email,
            messageId: info.messageId
          });

        } catch (err) {
          console.error(`Failed to send email to ${recipient.email}:`, err);

          // Retry once more with different settings if it's a Gmail error
          if (err.message && (err.message.includes('Invalid login') || err.message.includes('authentication'))) {
            console.log('Retrying with different authentication settings...');

            try {
              // Create a new transporter with optimized settings for retry
              const retryTransporter = nodemailer.createTransport({
                host: 'smtp.gmail.com',
                port: 465,
                secure: true,
                auth: {
                  user: process.env.EMAIL_USER,
                  pass: process.env.EMAIL_PASS
                },
                tls: {
                  rejectUnauthorized: false
                },
                // Enhanced settings for retry
                connectionTimeout: 90000, // 90 seconds
                socketTimeout: 180000, // 180 seconds
                // Slower rate for retry to ensure delivery
                rateDelta: 2000, // 2 seconds between messages
                rateLimit: 15 // 15 messages per second max
              });

              // Try sending again
              const info = await retryTransporter.sendMail(mailOptions);
              console.log(`Email sent successfully on retry to ${recipient.email}`);

              // Log success after retry
              results.success.push({
                email: recipient.email,
                messageId: info.messageId
              });

            } catch (retryErr) {
              console.error('Retry also failed:', retryErr);

              // Log failure
              results.failed.push({
                email: recipient.email,
                error: retryErr.message
              });
            }
          } else {
            // Log failure
            results.failed.push({
              email: recipient.email,
              error: err.message
            });
          }
        }

      } catch (emailError) {
        console.error(`Failed to send email to ${recipient.email}:`, emailError);
        results.failed.push({
          email: recipient.email || 'unknown',
          error: emailError.message
        });
      }
    }
  }

  // Log final results
  console.log(`Email sending complete: ${results.success.length} sent, ${results.failed.length} failed`);

})().catch(error => {
  console.error('Background email processing error:', error);
});

  } catch (error) {
    console.error('Error in email alert API:', error);
    // If we haven't sent the response yet
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        message: 'Failed to process email alert request',
        error: error.message
      });
    }
  }
});

// Helper function to get color based on alert severity
function getSeverityColor(severity) {
  switch (severity.toLowerCase()) {
    case 'critical':
      return '#c0392b';
    case 'high':
      return '#e74c3c';
    case 'medium':
      return '#f39c12';
    case 'low':
      return '#27ae60';
    default:
      return '#3498db';
  }
}

// Simple health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Test email endpoint
app.get('/api/test-email', async (req, res) => {
  try {
    // Get test recipient from query or use default
    const testEmail = req.query.email || process.env.TEST_EMAIL || process.env.EMAIL_USER;

    // Get additional test recipients if available
    const additionalRecipients = process.env.ADDITIONAL_TEST_EMAILS ?
      process.env.ADDITIONAL_TEST_EMAILS.split(',').filter(email => email !== testEmail) : [];

    console.log(`Sending test email to ${testEmail}${additionalRecipients.length > 0 ? ' and ' + additionalRecipients.length + ' additional recipients' : ''}`);

    if (additionalRecipients.length > 0) {
      console.log('Additional recipients:', additionalRecipients);
    }

    // Email content
    const mailOptions = {
      from: process.env.EMAIL_FROM,
      to: testEmail,
      bcc: additionalRecipients.join(','), // Add BCC recipients
      subject: 'Test Email from Disaster Management System',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #3498db; color: white; padding: 15px; text-align: center;">
            <h1>Test Email</h1>
          </div>

          <div style="padding: 20px; border: 1px solid #ddd; background-color: #f9f9f9;">
            <p>Hello,</p>

            <p>This is a test email from the Disaster Management System.</p>
            <p>If you're receiving this email, it means the email sending functionality is working correctly.</p>

            <p>Time sent: ${new Date().toLocaleString()}</p>

            <p>Regards,<br>Disaster Management System</p>
          </div>
        </div>
      `
    };

    // Send test email
    const info = await transporter.sendMail(mailOptions);

    console.log('Test email sent successfully!');
    console.log('Message ID:', info.messageId);

    res.json({
      success: true,
      message: 'Test email sent successfully',
      details: {
        messageId: info.messageId,
        recipient: testEmail
      }
    });

  } catch (error) {
    console.error('Failed to send test email:', error);

    res.status(500).json({
      success: false,
      message: 'Failed to send test email',
      error: error.message
    });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Email server running on port ${PORT}`);
  console.log(`Test the email server: http://localhost:${PORT}/api/test-email`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});
